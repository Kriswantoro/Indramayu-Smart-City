<?php
 
class DBOperations
{
    private $con;
 
    function __construct()
    {
        require_once dirname(__FILE__) . '\DBConnect.php';
        $db = new DBConnect();
        $this->con = $db->connect();
    }

	//postPengaduan
	public function postPengaduan($id_pengguna, $id_dinas, $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi, $status, $lat, $long, $tgl_pengaduan, $status_kirim){
		$kirim = 1;
		$name = "Operator";
		$judul = "Pengaduan";
		$deskripsi1 = "Ada Pengaduan";
		$is_read = 0;
		$timezone1 = date_default_timezone_set("Asia/Bangkok");
		$currentDateTime1 = date('Y-m-d H:i:s');
		$stmt = $this->con->prepare("INSERT INTO pengaduan (id_pengguna, id_dinas, judul_pengaduan, kategori, pesan, foto_pengaduan, lokasi, status, lat, lng, tgl_pengaduan, status_kirim) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("ssssssssssss", $id_pengguna, $id_dinas, $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi, $status, $lat, $long, $currentDateTime1, $kirim);
		$coba = $this->con->prepare("INSERT INTO notif (name, judul, deskripsi, is_read) VALUES (?, ?, ?, ?)");
		$coba->bind_param("ssss", $name, $judul , $deskripsi1, $is_read);
		$coba->execute();
		if($stmt->execute())
			return true; 
		return false; 
	}
	
	//getPengaduan
	public function getPengaduan(){
		$stmt = $this->con->prepare("SELECT id_pengaduan, pengaduan.id_pengguna, id_dinas, judul_pengaduan, kategori, pesan, foto_pengaduan, lokasi, status, lat, lng, tgl_pengaduan, pengguna.foto_pengguna, pengguna.nama_pengguna FROM `pengaduan` INNER JOIN pengguna ON pengaduan.id_pengguna=pengguna.id_pengguna ORDER BY id_pengaduan DESC");
		$stmt->execute();
		$stmt->bind_result($id_pengaduan, $id_pengguna, $id_dinas, $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi, $status, $lat, $lng, $tgl_pengaduan, $foto_pengguna, $nama_pengguna);
		base64_decode($foto_pengaduan);
		$pengaduan = array();
		
		while($stmt->fetch()){
			$temp = array(); 
			$temp['id_pengaduan'] = $id_pengaduan;
			$temp['id_pengguna'] = $id_pengguna;
			$temp['id_dinas'] = $id_dinas;
			$temp['judul_pengaduan'] = $judul_pengaduan; 
            $temp['kategori'] = $kategori; 
            $temp['pesan'] = $pesan; 
            $temp['foto_pengaduan'] = $foto_pengaduan; 
			$temp['lokasi'] = $lokasi; 
			$temp['status'] = $status;
			$temp['lat'] = $lat;
			$temp['lng'] = $lng;
			$temp['tgl_pengaduan'] = $tgl_pengaduan;
			$temp['foto_pengguna'] = $foto_pengguna;
			$temp['nama_pengguna'] = $nama_pengguna;
			array_push($pengaduan, $temp);
		}
		return $pengaduan; 
	}

	//getKategoriTempat
	public function getKategori(){
		$stmt = $this->con->prepare("SELECT id_kategori_tempat, nama_kategori FROM kategori_tempat");
		$stmt->execute();
		$stmt->bind_result($id_kategori_tempat, $nama_kategori);
		$kategori = array();
		
		while($stmt->fetch()){
			$temp = array();
			$temp['id_kategori_tempat'] = $id_kategori_tempat; 
			$temp['nama_kategori'] = $nama_kategori;
			array_push($kategori, $temp);
		}
		return $kategori; 
	}

		//getKategoriPengaduan
		public function getKategoriPengaduan(){
			$stmt = $this->con->prepare("SELECT id_kategori_pengaduan, nama_kategori_pengaduan, kategori_dinas.id_dinas, kategori_dinas.nama_dinas FROM `kategori_pengaduan` INNER JOIN kategori_dinas ON kategori_pengaduan.id_dinas=kategori_dinas.id_dinas");
			$stmt->execute();
			$stmt->bind_result($id_kategori_pangaduan, $nama_kategori_pengaduan, $id_dinas, $nama_dinas);
			$kategoriPengaduan = array();
			
			while($stmt->fetch()){
				$temp = array();
				$temp['id_kategori_pengaduan'] = $id_kategori_pangaduan; 
				$temp['id_dinas'] = $id_dinas;
				$temp['nama_kategori_pengaduan'] = $nama_kategori_pengaduan;
				$temp['nama_dinas'] = $nama_dinas;
				array_push($kategoriPengaduan, $temp);
			}
			return $kategoriPengaduan; 
		}
	
	//getTempat
	public function getTempat(){
		if (isTheseParametersAvailable(array('id_kategori_tempat'))) {
			$id_kategori_tempat = $_POST['id_kategori_tempat'];

		$stmt = $this->con->prepare("SELECT id_tempat, tempat.id_kategori_tempat, nama_tempat, foto_tempat, lat, lng, kategori_tempat.id_kategori_tempat, kategori_tempat.nama_kategori FROM tempat INNER JOIN kategori_tempat ON tempat.id_kategori_tempat=kategori_tempat.id_kategori_tempat WHERE tempat.id_kategori_tempat = ?");
		$stmt->bind_param("s",$id_kategori_tempat);
		$stmt->execute();
		$stmt->bind_result($id_tempat, $id_kategori_tempat, $nama_tempat, $foto_tempat, $lat, $lng, $id_kategori_tempat2, $nama_tempat2);
		$tempat = array();

		while($stmt->fetch()){
			$temp['id_tempat'] = $id_tempat;
			$temp['id_kategori_tempat'] = $id_kategori_tempat;
			$temp['nama_tempat'] = $nama_tempat;
			$temp['foto_tempat'] = $foto_tempat;
			$temp['lat'] = $lat;
			$temp['lng'] = $lng;
			array_push($tempat, $temp);
		}
		return $tempat; 
		}
	}
	//getsaran 
	public function getSaran(){

		$stmt = $this->con->prepare("SELECT id_saran, pengguna.id_pengguna, pengguna.nama_pengguna, saran.id_dinas, kategori_dinas.nama_dinas, judul_saran, deskripsi, tgl_saran FROM saran INNER JOIN pengguna ON saran.id_pengguna=pengguna.id_pengguna INNER JOIN kategori_dinas ON saran.id_dinas=kategori_dinas.id_dinas");
		$stmt->execute();
		$stmt->bind_result($id_saran, $id_pengguna, $nama_pengguna, $id_dinas, $nama_dinas, $judul_saran, $deskripsi, $tgl_saran);
		$getsaran = array();

		while($stmt->fetch()){
			
			$temp = array();
			$temp['id_saran'] = $id_saran;
			$temp['id_pengguna'] = $id_pengguna;
			$temp['id_dinas'] = $id_dinas;
			$temp['nama_pengguna'] = $nama_pengguna;
			$temp['nama_dinas'] = $nama_dinas;
			$temp['judul_saran'] = $judul_saran;
			$temp['deskripsi'] = $deskripsi;
			$temp['tgl_saran'] = $tgl_saran;
			array_push($getsaran, $temp);
			}
		return $getsaran; 
	}

	//getKategoriDinas
	public function getKategoriDinas(){
		$stmt = $this->con->prepare("SELECT id_dinas, nama_dinas FROM kategori_dinas");
		$stmt->execute();
		$stmt->bind_result($id_dinas, $nama_dinas);
		$kategori_dinas = array();
		
		while($stmt->fetch()){
			$temp = array();
			$temp['id_dinas'] = $id_dinas; 
			$temp['nama_dinas'] = $nama_dinas;
			array_push($kategori_dinas, $temp);
		}
		return $kategori_dinas; 

	}

	public function getRiwayatPengaduan(){
		if (isTheseParametersAvailable(array('status'), array('id_pengguna'))) {
			$status = $_POST['status'];
			$id_pengguna = $_POST['id_pengguna'];

			$stmt = $this->con->prepare("SELECT COUNT(status) FROM pengaduan WHERE status = ? AND id_pengguna = ?");
			$stmt->bind_param("ss",$status, $id_pengguna);
			$stmt->execute();
			$stmt->store_result();
			$riwayat = array();

			if($stmt->num_rows > 0){
				$stmt->bind_result($count);
				$stmt->fetch();

				$temp = array('count'=>$count);
				array_push($riwayat, $temp);
			}
			return $riwayat; 
		}
	}

	public function postSaran($id_pengguna, $id_dinas, $judul_saran, $deskripsi, $tgl_saran, $status_kirim_saran){
		$status_kirim_saran = 1;
		$name_saran = "Operator";
		$judul_saran = "Saran";
		$deskripsi_saran = "Ada Saran";
		$is_read_saran = 0;
		$timezone = date_default_timezone_set("Asia/Bangkok");
		$currentDateTime = date('Y-m-d H:i:s');
		$stmt = $this->con->prepare("INSERT INTO saran (id_pengguna, id_dinas, judul_saran, deskripsi, tgl_saran, status_kirim_saran) VALUES (?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("ssssss", $id_pengguna, $id_dinas, $judul_saran, $deskripsi, $currentDateTime, $status_kirim_saran);
		$coba = $this->con->prepare("INSERT INTO notif (name, judul, deskripsi, is_read) VALUES (?, ?, ?, ?)");
		$coba->bind_param("ssss", $name_saran, $judul_saran , $deskripsi_saran, $is_read_saran);
		$coba->execute();
		if($stmt->execute())
			return true; 
		return false; 
	}

		//getUser
		public function getUser(){
			$stmt = $this->con->prepare("SELECT id_pengguna, nik, foto_pengguna, nama_pengguna, email, no_tlpn, status_pengguna FROM pengguna");
			$stmt->execute();
			$stmt->bind_result($id_pengguna, $nik, $foto_pengguna, $nama_pengguna, $email, $no_tlpn, $status_pengguna);
			$getuser = array();
			
			while($stmt->fetch()){
				$temp = array();
				$temp['id_pengguna'] = $id_pengguna;
				$temp['nik'] = $nik; 
				$temp['foto_pengguna'] = $foto_pengguna;
				$temp['nama_pengguna'] = $nama_pengguna;
				$temp['email'] = $email;
				$temp['no_tlpn'] = $no_tlpn;
				$temp['status_pengguna'] = $status_pengguna;
				array_push($getuser, $temp);
			}
			return $getuser; 
		}

		public function updateUser($foto_pengguna, $no_tlpn, $id_pengguna){
			$sql = "UPDATE pengguna SET foto_pengguna=?, no_tlpn=? WHERE id_pengguna=?";
			$stmt = $this->con->prepare($sql); 
			$stmt->bind_param("sss",$foto_pengguna, $no_tlpn, $id_pengguna);
			if($stmt->execute())
			return true;
		return false;
		}

		//getlogin
	public function getlogin(){
		if (isTheseParametersAvailable(array('no_tlpn'))) {
			$no_tlpn = $_POST['no_tlpn'];

		$stmt = $this->con->prepare("SELECT id_pengguna, nik, foto_pengguna, nama_pengguna, email, no_tlpn, status_pengguna FROM pengguna WHERE no_tlpn = ?");
		$stmt->bind_param("s",$no_tlpn);
		$stmt->execute();
		$stmt->store_result();
		$getlogin = array();

		if($stmt->num_rows > 0){
			$stmt->bind_result($id_pengguna, $nik, $foto_pengguna, $nama_pengguna, $email, $no_tlpn, $status_pengguna);
			$stmt->fetch();
		
			$temp = array(
						'id_pengguna'=>$id_pengguna,
					 	'nik'=>$nik,
						'foto_pengguna'=>$foto_pengguna,
						'nama_pengguna'=>$nama_pengguna,
            			'email'=>$email, 
						'no_tlpn'=>$no_tlpn,
						'status_pengguna'=>$status_pengguna);
			array_push($getlogin, $temp);
			}
		return $getlogin; 
		}
	}

	//checknik
	public function checkNIK(){
		if (isTheseParametersAvailable(array('nik'))) {
			$nik = $_POST['nik'];

		$stmt = $this->con->prepare("SELECT * FROM nik_user WHERE nik = ?");
		$stmt->bind_param("s",$nik);
		$stmt->execute();
		$stmt->store_result();
		$checkNik = array();

		if($stmt->num_rows > 0){
			$stmt->bind_result($nik, $nama);
			$stmt->fetch();
		
			$temp = array(
						'nik'=>$nik,
						'nama'=>$nama);
			array_push($checkNik, $temp);
			}
		return $checkNik; 
		}
	}

	//postregister
	public function postRegister($nik, $foto_pengguna, $nama_pengguna, $email, $no_tlpn, $status_pengguna){
		$status = 1;
		$stmt = $this->con->prepare("INSERT INTO pengguna (nik, foto_pengguna, nama_pengguna, email, no_tlpn, status_pengguna) VALUES (?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("ssssss", $nik, $foto_pengguna, $nama_pengguna, $email, $no_tlpn, $status);
		if($stmt->execute())
			return true; 
		return false; 
	}

	public function addNomor($nama, $nomor){
		$stmt = $this->con->prepare("INSERT INTO panggilan_pengaduan (nama, nomor) VALUES (?,?)");
		$stmt->bind_param("ss", $nama, $nomor);
		if($stmt->execute())
			return true;
		return false;
	}

	public function getNomor(){
		$stmt = $this->con->prepare("SELECT * FROM panggilan_pengaduan");
		$stmt->execute();
		$stmt->bind_result($id_panggilan, $nama, $nomor);
		$nomorPanggilan = array();
		
		while($stmt->fetch()){
			$temp = array();
			$temp['id_panggilan'] = $id_panggilan; 
			$temp['nama'] = $nama;
			$temp['nomor'] = $nomor;
			array_push($nomorPanggilan, $temp);
		}
		return $nomorPanggilan; 
	}

}