<?php 
	
	require_once '../include/DBOperations.php';
	$response = array();  
	if(isset($_GET['apicall'])){
		
		switch($_GET['apicall']){
			
			case 'postpengaduan':
                if(
                isset($_POST['judul_pengaduan']) &&
                isset($_POST['kategori']) && 
                isset($_POST['pesan']) &&
                isset($_POST['foto_pengaduan']) &&
                isset($_POST['lokasi_pengaduan'])){
                    $db = new DBOperations();
					if($db->postPengaduan($_POST['judul_pengaduan'], $_POST['kategori'], $_POST['pesan'], $_POST['foto_pengaduan'],$_POST['lokasi_pengaduan'])){
						$response['error'] = false;
                        $response['message'] = 'pengaduan added successfully';
					}else{
						$response['error'] = true;
						$response['message'] = 'Could not add pengaduan';
					}
				}else{
					$response['error'] = true; 
					$response['message'] = 'Required Parameters are missing';
				}
			break; 
			
			//if it is getartist that means we are fetching the records
			case 'getpengaduan':
				$db = new DBOperations();
				$pengaduan = $db->getPengaduan();
				if(count($pengaduan)<=0){
					$response['error'] = true; 
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false; 
					$response['data'] = $pengaduan;
				}
			break; 
			
			default:
				$response['error'] = true;
				$response['message'] = 'No operation to perform';
			
		}
		
	}else{
		$response['error'] = false; 
		$response['message'] = 'Invalid Request';
	}
	
	//displaying the data in json 
	echo json_encode($response);