<?php 
	
	require_once '../include/DBOperations.php';
	$response = array();  
	if(isset($_GET['apicall'])){
		
		switch($_GET['apicall']){
			
			case 'postpengaduan':
                if(
                isset($_POST['judul_pengaduan']) &&
                isset($_POST['kategori']) && 
                isset($_POST['pesan']) &&
                isset($_POST['foto_pengaduan']) &&
				isset($_POST['lokasi_pengaduan']) &&
				isset($_POST['id_status_pengaduan'])){
                    $db = new DBOperations();
					if($db->postPengaduan($_POST['judul_pengaduan'], $_POST['kategori'], $_POST['pesan'], $_POST['foto_pengaduan'],$_POST['lokasi_pengaduan'],$_POST['id_status_pengaduan'])){
						$response['error'] = false;
                        $response['message'] = 'pengaduan added successfully';
					}else{
						$response['error'] = true;
						$response['message'] = 'Could not add pengaduan';
					}
				}else{
					$response['error'] = true; 
					$response['message'] = 'Required Parameters are missing';
				}
			break; 
			
			case 'getpengaduan':
				$db = new DBOperations();
				$pengaduan = $db->getPengaduan();
				if(count($pengaduan)<=0){
					$response['error'] = true; 
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false; 
					$response['message'] = 'Sukses';
					$response['data'] = $pengaduan;
				}
			break; 

			case 'gettempat':
				$db = new DBOperations();
				$tempat = $db->getTempat();
				if(count($tempat)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['message'] = 'Sukses';
					$response['data'] = $tempat;
				}
			break;

			case 'getkategori':
				$db = new DBOperations();
				$kategori = $db->getKategori();
				if(count($kategori)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['data'] = $kategori;
				}
			break;

			case 'getsaran':
				$db = new DBOperations();
				$getsaran = $db->getSaran();
				if(count($getsaran)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['data'] = $getsaran;
				}
			break;

			case 'postsaran':
                if(
                isset($_POST['judul_saran']) &&
				isset($_POST['deskripsi']) &&
				isset($_POST['tgl_saran'])){
                    $db = new DBOperations();
					if($db->postSaran($_POST['judul_saran'], $_POST['deskripsi'], $_POST['tgl_saran'])){
						$response['error'] = false;
                        $response['message'] = 'saran added successfully';
					}else{
						$response['error'] = true;
						$response['message'] = 'Could not add pengaduan';
					}
				}else{
					$response['error'] = true; 
					$response['message'] = 'Required Parameters are missing';
				}
			break;
			
			case 'getuser':
				$db = new DBOperations();
				$getuser = $db->getUser();
				if(count($getuser)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['data'] = $getuser;
				}
			break;

			case 'getlogin':
				$db = new DBOperations();
				$getlogin = $db->getLogin();
				if(count($getlogin)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['message'] = 'Sukses';
					$response['data'] = $getlogin;
				}
			break;

			case 'postregister':
                if(
                isset($_POST['foto_pengguna']) &&
				isset($_POST['nama_pengguna']) &&
				isset($_POST['email']) &&
				isset($_POST['no_tlpn'])){
                    $db = new DBOperations();
					if($db->postRegister($_POST['foto_pengguna'], $_POST['nama_pengguna'], $_POST['email'], $_POST['no_tlpn'])){
						$response['error'] = false;
                        $response['message'] = 'register user added successfully';
					}else{
						$response['error'] = true;
						$response['message'] = 'Could not register';
					}
				}else{
					$response['error'] = true; 
					$response['message'] = 'Required Parameters are missing';
				}
			break;

			default:
				$response['error'] = true;
				$response['message'] = 'No operation to perform';
			
		}
		
	}else{
		$response['error'] = false; 
		$response['message'] = 'Invalid Request';
	}
	
	//displaying the data in json 
	echo json_encode($response);
	function isTheseParametersAvailable($params){
		foreach ($params as $param) {
			if (!isset($_POST[$param])) {
				return false;
			}
		}
	
		return true;
	}