<?php
 
class DBOperations
{
    private $con;
 
    function __construct()
    {
        require_once dirname(__FILE__) . '\DBConnect.php';
        $db = new DBConnect();
        $this->con = $db->connect();
    }

	//postPengaduan
	public function postPengaduan($judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi_pengaduan, $id_status_pengaduan){
		$stmt = $this->con->prepare("INSERT INTO pengaduan (judul_pengaduan, kategori, pesan, foto_pengaduan, lokasi_pengaduan, id_status_pengaduan) VALUES (?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("ssssss", $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi_pengaduan, $id_status_pengaduan);
		if($stmt->execute())
			return true; 
		return false; 
	}
	
	//getPengaduan
	public function getPengaduan(){
		$stmt = $this->con->prepare("SELECT * FROM `pengaduan` INNER JOIN status_pengaduan ON pengaduan.id_status_pengaduan=status_pengaduan.id_status_pengaduan");
		$stmt->execute();
		$stmt->bind_result($id_pengaduan, $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi_pengaduan, $id_status_pengaduan, $id_status_pengaduan2, $status);
		$pengaduan = array();
		
		while($stmt->fetch()){
			$temp = array(); 
			$temp['id_pengaduan'] = $id_pengaduan; 
			$temp['judul_pengaduan'] = $judul_pengaduan; 
            $temp['kategori'] = $kategori; 
            $temp['pesan'] = $pesan; 
            $temp['foto_pengaduan'] = $foto_pengaduan; 
			$temp['lokasi_pengaduan'] = $lokasi_pengaduan; 
			$temp['id_status_pengaduan'] = $id_status_pengaduan;
			$temp['status_pengaduan.id_status_pengaduan'] = $id_status_pengaduan2;
			$temp['status_pengaduan.status'] = $status;
			array_push($pengaduan, $temp);
		}
		return $pengaduan; 
	}

	//getKategoriTempat
	public function getKategori(){
		$stmt = $this->con->prepare("SELECT * FROM kategori_tempat");
		$stmt->execute();
		$stmt->bind_result($id_kategori_tempat, $nama_tempat);
		$kategori = array();
		
		while($stmt->fetch()){
			$temp = array();
			$temp['id_kategori_tempat'] = $id_kategori_tempat; 
			$temp['nama_tempat'] = $nama_tempat;
			array_push($kategori, $temp);
		}
		return $kategori; 
	}

	//getTempat
	public function getTempat(){
		if (isTheseParametersAvailable(array('id_kategori_tempat'))) {
			$id_kategori_tempat = $_POST['id_kategori_tempat'];

		$stmt = $this->con->prepare("SELECT * FROM tempat INNER JOIN kategori_tempat ON tempat.id_kategori_tempat=kategori_tempat.id_kategori_tempat WHERE tempat.id_kategori_tempat = ?");
		$stmt->bind_param("s",$id_kategori_tempat);
		$stmt->execute();
		$stmt->store_result();
		//$stmt->bind_result($id_tempat, $id_kategori_tempat, $nama_tempat, $foto_tempat, $lat, $lng, $id_kategori_tempat2, $nama_tempat2);
		$tempat = array();

		if($stmt->num_rows > 0){
			$stmt->bind_result($id_tempat, $id_kategori_tempat, $nama_tempat, $foto_tempat, $lat, $lng, $id_kategori_tempat2, $nama_tempat2);
			$stmt->fetch();
		
		//while($stmt->fetch()){
			$temp = array(
						'id_tempat'=>$id_tempat,
						'id_kategori_tempat'=>$id_kategori_tempat,
						'nama_tempat'=>$nama_tempat,
            			'foto_tempat'=>$foto_tempat, 
            			'lat'=>$lat,
						'lng'=>$lng,
						'kategori_tempat.id_kategori_tempat'=>$id_kategori_tempat2,
						'kategori_tempat.nama_tempat'=>$nama_tempat2);
			array_push($tempat, $temp);
			}
		return $tempat; 
		}
	}

	//getsaran
	public function getSaran(){
		$stmt = $this->con->prepare("SELECT * FROM saran");
		$stmt->execute();
		$stmt->bind_result($id_saran, $judul_saran, $deskripsi, $tgl_saran);
		$getsaran = array();
		
		while($stmt->fetch()){
			$temp = array();
			$temp['id_saran'] = $id_saran; 
			$temp['judul_saran'] = $judul_saran;
			$temp['deskripsi'] = $deskripsi;
			$temp['tgl_saran'] = $tgl_saran;
			array_push($getsaran, $temp);
		}
		return $getsaran; 
	}

	public function postSaran($judul_saran, $deskripsi, $tgl_saran){
		$timezone = date_default_timezone_set("Asia/Bangkok");;
		$currentDateTime = date('Y-m-d H:i:s');
		$stmt = $this->con->prepare("INSERT INTO saran (judul_saran, deskripsi, tgl_saran) VALUES (?, ?, ?)");
		$stmt->bind_param("sss", $judul_saran, $deskripsi, $currentDateTime);
		if($stmt->execute())
			return true; 
		return false; 
	}

		//getUser
		public function getUser(){
			$stmt = $this->con->prepare("SELECT * FROM pengguna");
			$stmt->execute();
			$stmt->bind_result($id_pengguna, $foto_pengguna, $nama_pengguna, $email, $no_tlpn);
			$getuser = array();
			
			while($stmt->fetch()){
				$temp = array();
				$temp['id_pengguna'] = $id_pengguna; 
				$temp['foto_pengguna'] = $foto_pengguna;
				$temp['nama_pengguna'] = $nama_pengguna;
				$temp['email'] = $email;
				$temp['no_tlpn'] = $no_tlpn;
				array_push($getuser, $temp);
			}
			return $getuser; 
		}

		//getlogin
	public function getlogin(){
		if (isTheseParametersAvailable(array('no_tlpn'))) {
			$no_tlpn = $_POST['no_tlpn'];

		$stmt = $this->con->prepare("SELECT * FROM pengguna WHERE no_tlpn = ?");
		$stmt->bind_param("s",$no_tlpn);
		$stmt->execute();
		$stmt->store_result();
		$getlogin = array();

		if($stmt->num_rows > 0){
			$stmt->bind_result($id_pengguna, $foto_pengguna, $nama_pengguna, $email, $no_tlpn);
			$stmt->fetch();
		
		//while($stmt->fetch()){
			$temp = array(
						'id_pengguna'=>$id_pengguna,
						'foto_pengguna'=>$foto_pengguna,
						'nama_pengguna'=>$nama_pengguna,
            			'email'=>$email, 
            			'no_tlpn'=>$no_tlpn);
			array_push($getlogin, $temp);
			}
		return $getlogin; 
		}
	}

	//postregister
	public function postRegister($foto_pengguna, $nama_pengguna, $email, $no_tlpn){
		$stmt = $this->con->prepare("INSERT INTO pengguna (foto_pengguna, nama_pengguna, email, no_tlpn) VALUES (?, ?, ?, ?)");
		$stmt->bind_param("ssss", $foto_pengguna, $nama_pengguna, $email, $no_tlpn);
		if($stmt->execute())
			return true; 
		return false; 
	}
}