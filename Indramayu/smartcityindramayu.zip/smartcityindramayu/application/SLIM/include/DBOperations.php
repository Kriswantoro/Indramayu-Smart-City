<?php
 
class DBOperations
{
    private $con;
 
    function __construct()
    {
        require_once dirname(__FILE__) . '\DBConnect.php';
        $db = new DBConnect();
        $this->con = $db->connect();
    }

	//postPengaduan
	public function postPengaduan($judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi_pengaduan){
		$stmt = $this->con->prepare("INSERT INTO pengaduan (judul_pengaduan, kategori, pesan, foto_pengaduan, lokasi_pengaduan) VALUES (?, ?, ?, ?, ?)");
		$stmt->bind_param("sssss", $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi_pengaduan);
		if($stmt->execute())
			return true; 
		return false; 
	}
	
	//getPengaduan
	public function getPengaduan(){
		$stmt = $this->con->prepare("SELECT * FROM pengaduan");
		$stmt->execute();
		$stmt->bind_result($id_pengaduan, $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi_pengaduan);
		$pengaduan = array();
		
		while($stmt->fetch()){
			$temp = array(); 
			$temp['id_pengaduan'] = $id_pengaduan; 
			$temp['judul_pengaduan'] = $judul_pengaduan; 
            $temp['kategori'] = $kategori; 
            $temp['pesan'] = $pesan; 
            $temp['foto_pengaduan'] = $foto_pengaduan; 
            $temp['lokasi_pengaduan'] = $lokasi_pengaduan; 
			array_push($pengaduan, $temp);
		}
		return $pengaduan; 
	}
}