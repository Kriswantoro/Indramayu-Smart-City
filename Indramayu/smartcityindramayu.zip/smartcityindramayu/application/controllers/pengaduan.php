<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class engaduan extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }

    //Menampilkan data pengaduan
    function index_get() {
        $idpengaduan = $this->get('id_pengaduan');
        if ($idpengaduan == '') {
            $pengaduan = $this->db->get('pengaduan')->result();
        } else {
            $this->db->where('id_pengaduan', $idpengaduan);
            $pengaduan = $this->db->get('pengaduan')->result();
        }
        $this->response($pengaduan, 200);
    }

     //Mengirim atau menambah data kontak baru
     function index_post() {
        $data = array(
                    'judul_pengaduan'=> $this->post('judul_pengaduan'),
                    'kategori'=> $this->post('kategori'),
                    'pesan'=> $this->post('pesan'),
                    'foto_pengaduan'=> $this->post('foto_pengaduan'),
                    'lokasi_pengaduan'=> $this->post('lokasi_pengaduan'));
        $insert = $this->db->insert('pengaduan', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
}
?>