-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 08 Agu 2020 pada 06.15
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `image`
--

CREATE TABLE `image` (
  `id` int(10) NOT NULL,
  `path` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `image`
--

INSERT INTO `image` (`id`, `path`, `description`) VALUES
(1, 'uploads/5f24fb24dd92f.jpg', 'hay');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_dinas`
--

CREATE TABLE `kategori_dinas` (
  `id_dinas` bigint(20) UNSIGNED NOT NULL,
  `nama_dinas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kategori_dinas`
--

INSERT INTO `kategori_dinas` (`id_dinas`, `nama_dinas`, `created_at`, `updated_at`) VALUES
(1, 'Dinas Pendidikan', NULL, NULL),
(2, 'Dinas Lingkungan Hidup', NULL, NULL),
(3, 'Dinas PUPR', NULL, NULL),
(4, 'Dinas Kesehatan', NULL, NULL),
(5, 'Dinas Pendidikan dan Olahraga', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_pengaduan`
--

CREATE TABLE `kategori_pengaduan` (
  `id_kategori_pengaduan` int(11) NOT NULL,
  `nama_kategori_pengaduan` varchar(255) NOT NULL,
  `id_dinas` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kategori_pengaduan`
--

INSERT INTO `kategori_pengaduan` (`id_kategori_pengaduan`, `nama_kategori_pengaduan`, `id_dinas`) VALUES
(1, 'Pendidikan', 1),
(2, 'Lingkungan Hidup', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_tempat`
--

CREATE TABLE `kategori_tempat` (
  `id_kategori_tempat` bigint(20) UNSIGNED NOT NULL,
  `nama_kategori` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kategori_tempat`
--

INSERT INTO `kategori_tempat` (`id_kategori_tempat`, `nama_kategori`, `created_at`, `updated_at`) VALUES
(1, 'Ibadah', NULL, NULL),
(2, 'Kesehatan', NULL, NULL),
(3, 'Kantor Polisi', NULL, NULL),
(4, 'Wisata', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2020_05_03_144838_create_pengaduan_table', 1),
(4, '2020_07_12_111531_create_kategori_tempat_table', 1),
(5, '2020_07_12_111846_create_tempat_table', 1),
(6, '2020_07_13_062812_create_saran_table', 1),
(7, '2020_07_13_063351_create_pengguna_table', 1),
(8, '2020_07_13_172029_create_status_pengaduan_table', 1),
(9, '2020_07_18_082600_create_permission_tables', 1),
(10, '2020_07_19_171245_create_kategori_dinas_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(2, 'App\\User', 2),
(3, 'App\\User', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `nik_user`
--

CREATE TABLE `nik_user` (
  `nik` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `nik_user`
--

INSERT INTO `nik_user` (`nik`, `nama`) VALUES
(43214321, 'Ini Aku'),
(123123123, 'Nandia'),
(123456789, 'Kris'),
(321321321, 'Siapa yaa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id_pengaduan` bigint(20) UNSIGNED NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `id_dinas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul_pengaduan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pesan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_pengaduan` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `lokasi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lng` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_kirim` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengaduan`
--

INSERT INTO `pengaduan` (`id_pengaduan`, `id_pengguna`, `id_dinas`, `judul_pengaduan`, `kategori`, `pesan`, `foto_pengaduan`, `lokasi`, `status`, `lat`, `lng`, `status_kirim`, `created_at`, `updated_at`) VALUES
(44, 8, '1', 'hahhahahaa', 'Pendidikan', 'hahahhahaa', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdC\nIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAA\nAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlk\nZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAA\nAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAA\nAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\nAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAA\nAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3Bh\ncmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADT\nLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAw\nADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAj\nJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgo\nKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIALsA+gMBIgACEQEDEQH/xAAcAAABBQEB\nAQAAAAAAAAAAAAAEAQIDBQYHAAj/xABEEAABAwIEAwUEBgcHBAMAAAABAgMRAAQFEiExBkFREyJh\ncYEUkaGxBzJSwdHwFiMzQmKC4RVDY3KSsvEkU6LCVHSz/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAEC\nAwT/xAAeEQEBAQEAAwADAQAAAAAAAAAAARECEiExAyJBYf/aAAwDAQACEQMRAD8A+bn7p50EuuKI\n86Vl11xhLJWopUqQknah1DMoIHPU+VTIWptYW2SlSTII5VRo8RZNnhgcbKAho9iO8MxcIlRidgOf\nlWZSO0eSk6pTqac4tSypbiionUknenMApZKuaz8KJJh2YlebnM1PiF4u8LZcSkZE5RlFD1G6YSaK\nuOFLXtr5y4UO60IB8a1cJGkisozduYbh7TDIAcWO0Wrz2oG6xK77qg+sLnQioizx2yW9fqWHmkoK\nRqo7elLhOD2rrku3QfUgzkToKp1FaiVOElR1JNWfCjRcv339cracojqaKvbqJI2qPD28zq19BFPu\ntCZ0ovC2YtwSIzGaCRLYOhBg0Q82goTpC/4hr/SlDc6RT8hnn60AwTrTssVP2e9L2dAKUaVEpNGq\nRvUSk66UHQ/oabhGKLjQltP+78a6UqsH9ELcYVfL5l8D3JH41u51UOlcuvrURqphFPVTKimkaVVY\nV3cTxJH+IlXvSKtjVW2w+zil28hsKQ6EQc0agazSz3BZKcQkpClAFRgTzoTGkBzCrlP+GT7taAxU\nrDto4+ghSXO6GypQk9RpViph55pSHXjlUIORIHzmtbuxAmCOBblxH74Q570gfdTMWTkfC8jh00IV\nI93Ki7SwFtcBTav1YaS2EnfQnX40zGgPZwdJSZgmOVSz9Mp/Tr2VWyVI30M0rRzMoO8ikYBuLBBU\nCCpPPSpG2+zbCSZjnSfdREoUzJU6hTIFUfJV1am1VldKS+rVQTskdKHianuFqeeW4rUqM0wIJOnx\nrqiFSc60NjdRohyCqE/VGg8qbbJIS4+Rv3EfeaWKBppbVr2m+aa2SO8ryFeOgmicNT2Vlc3R3cPZ\nI++gtmbGwvsKxHEH8QaYuGf2Vsfrr5CBzHXpWZIz3aU8k6miYAknYa1DZDNncO5NEaDiHFrK8wyx\nYtMObt3bduHH57zhjptHxo7hS2UxgvaEQt5RXPhyrK3KFLyNoBKnDlAHOugloW9kzbJ0S2gJPnUW\nKu510T61e2rPZsoSdwBNVLaO2vWW9IzVpAgRQQZKclFTpRpShGvhQQZdadkjlU4TB50uWqA1J8Kh\nWiaPWjlQ60VB0r6J0xgN0Y3uTr/Kmtk6kkEoJCqzH0aN5OGgr7bq1fd91ao7Vyv1tCumVIumGoGm\nkJilNNJ1q6hFISuMyQQDOvWnzULqnBHZoSrrmVH3VGfaFDdtPvV+FXTBWaoLllt8AOgkAzEka0zs\nniO89B/hSB85r3s8iFOuq/mj5UvWiRCEoQEoEAV401tlLU5cxnqon50800REUyPOpVDnTaaPlBWG\nXCVfrl29uP41yfhRWHYRZXLwQ9fdqsf3aRln8aBVU/D1qb3GBlnKyJJHWu1mMyvY0ts3ZaYSEtND\nKkCgIqyfwfFDcOJTZqOphSliD41I3w7eqj2i5tbcc+9JqGKd9KuzASCSs5R4mtPfYDdpwmwatGQt\naRKxmgyas8F4atbJ0XDjpunR9UkQE+laGCofn8/Oi4583wrirzZDxt2UHmVT8q8jh+zYATdYulMf\nutj+taXi27Vb4f2bSsqnDlJB1j8isLrRG0wDCcHZUt+ycFy+iCVKUFFM+HL1ou+kHL1+Ov561RfR\n+wVOX92owkEIB+J+6rm8XKllX1j13P59aD2DthzEFkDuoBjz/M8q0CUaeNVXDLUMOux9dcegq9Cd\nYMUNQhFKE6bfCp8mmopcumugoiDL4CkCIiiI0OleKPAwdqKFWiZ61C4kAHrRke6oHE786I6h9H4j\nha18VL/3mtA4oIQVK2Ak1S8Eo7PhmySeij71E1cP5uzV2cZ40naa41uAm79p91KGQ4oETmyED40Q\naES2Wng446wFLMd1EFXhM0XWed/q01RplPNNNVCV6vCvUHqWkpao8dqr7twofTCtOYk0Q7dNNuBt\naoURO1RX6AUpWBJBrn1fXpYImRTfSkaVnbSocxSx4VdV8k3Kw20pVHYTcuYdYQzCX3jmUveByqOy\nwu7xBQVcMqYsm++pSkwVUrywp0qI7s6AchyFeu+3L4e9e3LhJcuHTP8AERQTq+6ST51Y37Nj7Ol6\nxu1qVsph5BCweoIkEe4+FU14SG8qfrLOUVKNp9HvbHDX3HFKLSnIQCdvz6VrUpA56T+fzpQWA2Qs\nsItmAmCEAq05nU0e8Q0wpav3QT+fjUaY3HDa3XE9vaX7q2LRKgh1wDVE7mD0qm4sZwyxxC4awW4d\nuLVoZe2cjvq5kRyqC9dNxduvH99RNA3SFPu29s2JW84EgetGW74StvZOGWJ0cdBd8TOnnt0nypl4\nT2X8M+k/L4Cru6Qm2t0sIHcbSlAPLQQJ06A7wapHkqefZaghSlBOu+vx28xRWkwdjsrBlJnadfGr\nAIEiDrTm0hKUhIgR8qfl0gHSiIinTWlygGN6mynT4UmTw03oIY1JmvFBCRqdelTBPTavZNPEUUIt\nPIxFQuJ/5FFuCdhUKwDvrG8UR1ThpITgGHxsWUn3ij3gVNqCVFJI0I5UNgqcmD2SCIKWUCP5RRFw\n6hlpS3DCQNTXKtszZNlGKIWHVOKK1AtndA17xgQJ+/nWirP2rgcxFsmQQ4R20KBWYPdM7f0q/rj+\nP4108aidUUpJAJgTA51LTTXRln2OI2kvdlfMOWq5/fEirph9t9AWytK0nYpM0lzas3KCh9tDieih\nNUr/AA6Gll3DLhy2XvlmUmsftz/q+l/TqyisZvcKfSzirSXEnZ1vmK1DagtCVDYiRW+ep0mKrGkS\n60rQKggHaPGaNAKbQZlFZAmedDYw2teTJmIkaBJP30S0CbVKdfqxqINcc/atfw2zc7RJAHdB0MzN\nEQPCgrByFFCp6gxRulXn3FfN6caViuDISopZcec7NRO0cz8aor1kMPlCXW3kwCFoMgg/I+FX7/Dj\n/wDYdo1ZBr2hvVQWYmd9RVenhTGF/Wesmv5ifur265WVURNFYDYKxHiO3aQAttn9Y4QdBzirhrgi\n5eEXOKISI1DbZP3itdguEWWCWhbtwEpOq3Vbq86lWQeAZ66++qni1/2XAn1k5Uq7skdSB99GnF8P\nCSRdsmPsqmaEuMdwl5C2X1BxteikqaUQfhrQcvVe24Org9AaueDbBeJ48i+bQr2K0GbO4mApcaAb\niZ+VaT2/hK3WkKw63CDpnVbBQT7xPwrWZmfYW1Wpb7BbYydnATl5QKIpcRVC3J6Rz08PDkNZFBYQ\n2X8WtgRKUAr/AK9N+nSiL1R7QlWgAPM9PePlRPCLKi8+8UwICQdp6+HIUF+EwmJpyRGo6e6pUoEG\nSOoHWlySdpoiICJgiOleyAwTtUqUTO8+NKESfEeFFREQaRQ15HrUxGsEmfOkKRHLSgEWnWoXBAJA\nMxrRi0ECNz4CoVN5+7zMCiOq2Yy2rKeiAPhSXTSH2lIcEpPKYp6O6hI6Corp9LLRWrYQNTFcrme2\nlFZW6famXGkqK8xKwpJhGh2Udz76vaqrJrNdh/IJM95CgB7hv61amuf45kapvOvUpr1bR6kO1LXj\nUGNxRr2vitq3uyex0yjqIn51sEpASANAKy/GLZYfs75sd5tUH5j7601u4l5lDiDKVAKBrnx66sWg\n8VS8pCexnQyYJBpcPJLKkrBCknUEyaJum+0ZUASDuIMVXYU6kOuIK5KoIzHUmp166WfEzTaU3KpU\nM87Aa0ZQi0FNyFqKQJ9aLrXKV8y3GN3zqlFDxaQdAlIGg86DXfXRmbp8yZ/aH8aibbcdJDSFLKUl\nRgTAAkmoSda9bnqK+uHW1NOtuLDwWMqgozWyx++eeQzbLJGVtJdT1VGxFZHDbcX/ABFZ25/ZtnOv\nyGp+Aq7u3S/cOOndRn05VFDK00FROqM1e4I52FtcOm8daSe72bTy21KO4MhKhyO9UL5Li1KJUSTM\nqMn1NBX4isIs3iY1Ee/Sum8MpVb8J4Yh0q7QtycytsxJGvSCNK5ldsqurqyskDvPuhPxj766/iOV\npCW2gEobACRvAAiNdx+etCKG9UBlKyZEgDNt4dQfhr51fcKsZMKSoxLilLOvjA+VZu9JVnjZJ0id\nPAH8a3WH25trVhqCMiAmQOYFWlPSDBiJjnT8pBIM9PCnQdQdBzFKEmJ6bVBH0PKlyiRry0JqYJOm\n2lLlIO0AculBEEiOQI113pFADlvUwQYPu11p2XKAB8RQBqSN9R5c6a21N0zOwcSD6kUUpGxPPlTr\ndoKvWBA1dR8xQdAGwqG5CyiG1JSo81CamBgUNeIWtA7P64Miud+KDt7O3aus5czXEa6gfAUdQTaC\nlxoOog5iQoGZMHejaxyter1LFIKo9XqdEV6KgrMfsze4W80kSuJT5io+GUXCMJabukKQtEpAV05V\ncRSFSU7kCs+PvyXTHSENqUr6oEmqu0aSLgJcykgwkhW0a1Yu3TASQtSSI1FV6sRsLdWZIQFDmBS8\nW2GyJrtKw8CI1EUSEkga1n8Q4ntmkDKQTO+9V/6ao5pFPGyp5R8/E0niTAG5qPtm51db/wBQqJb6\nrlXsdi2p197uDKPlXqYXHCQKbHE8QVILpDCPXU+4AVMrarfFML/sHhaxbc0KFZnSBOqhv6HSsuvE\n7Wf2o9xqLVzhrzqnUWyMgS4qCpSQSkHQweWlHLLPZXbiE2qmQ2SG0tJJTm7o728gkVmmsYYZdDjT\n5QrkQDzr1zxGpbfZh165JPdaJOUnlI/CgsuCbQX3HTRUoBqzbKySNJ2HxV8K3+I/WUJ0g8p/5Hyq\nr+j3ALnBrC4v8SSpu/vDJSoQptO+o6k8vSrDEHZUVCSnMCCnQCenQ/nkKKrWG+3xG1aCVw5lJBPI\nHXzGn5it8lIAiCYG9Y/hZntcZUrLHYJUfUwNuRifdW1Gx5eJpUqEkpIUlJP53pUoJSJ2qXKdDoR1\nPnTkJEanU86giQhOU6fjUgQUiRt4VLEiYBAp6ECdI0NBCBpoCZ1ma8UEKnQHyorJqIESa8UaxGnI\n0AnZ6gAEGKks0g4jZgRo59xNEdkQowNPhUlsiMRtTAEKOnoaUacUPemEpnNlnXLM/Cpkmo7ppTqM\nqHCg9RzrF+LATKCi4bUSCVz3TqUij4oW1ZWwtQUhJkznBosa1jmelpsUoFLApQKpr0TTXXENJJUQ\nK86sNtlR5ViOIcYW46WmVacyK1JrPXWLjEuIWmJSggkVnLvH7h4kIMA1UkFRlRk05LdbnMjje7T3\nLu4cPecVr40OoKOpUT60QEaUhRFaxnQNykdkc2tVvZKOo2NXRIzZVDfbxpexR9kVLNWXGJNrwUhI\nlLYI6lwz8a1HDllgzTXb4KzbZVSCtGp8pOtc0QM6gnTXTWrP6P792zssYfb1ZBSGweSiTFR6JXRc\nTusOZZU1iDrAaUJ7N0jvDyrPhXA4WS41aLJ0/Zq06RpH59ay9w4pxxS3Vla1GVKO5NQk0NbJlzgg\naljD/wDMbedfdV3w4nhi5uVKwZrDO3bnvNNJSsDrtIHjXMM/SmWFw5Y8W4O7alSXnHUAhJjMCqPj\nqKprs2JkJTG2x118Ky18Zzd5RJSQeunzHj+Aq/xVau2UlIiJEkan8/0rOX7gCZKiQCFAJ0Go1jof\nzyFBecFMgt3L4EZ1BO86BP8AWtOdABEcqrOF7fscFtk6d4Z9o31+UVbJjNA+sNOmlRCIQI0id9Kc\nlIMR1inIToDsdqmSO9oNY50ESUd4jTwqdKApRmdp6UqWjuD4wKmZbggwc42TzoEQg5QCSKehqEwR\nE61K20SNhHwqZKAY0mgGS2CSDoNxQ9028y4zcNIKy2ZKRuQd6t0sgqqUtQQBJB30oAGcXYVAJcCu\nhQr8KerGLZJEqVrt3FfhRaWPsgU5TISnRImdhUxQRxe1jVSx/Ir8KQ4xbCSA6QNP2avwqZ1kx9WR\nuIFMLZCiZ18edTFRDGbeJCXtdv1Zrwxu3zAZHv8AQaRbUGRJ61AWwJKgPKp4iq4k4rtWbZQSl0aR\nqg1gDxDbFRUpLpJP2aI47fPtPZjr76yekV05mOPfutIeI7Uf3T3+ml/Sa1H9097qzKiDM1ETWsYx\nqFcU242YePpUauLLf/sO/CsstUUO4aGNS5xWxIIt3PfSfpYz/wDHcrHrVpTJHUe6rDxgW6d7GyfX\nzy5B5nT5SfSr3C2PYuFrJsgBy5Wq4V1jZNZ28aXcvWNi3OZ9wGI3k5R/7VsMccR7aW2cvZMpDSIE\naAdPOa5vQrm2nH3ktMpUtajASlJJ9wp+K2IsVhIuW3lfvJSlSSkxzCgKba9mu7aDyihorGZXQTrR\nPEdyh51lttaCltEFLbq1oCiT9XMTyjbSiKgGSNqO4JthiH0gIKtWrJsrMpkCBGvTvKoJkJDgU5Ib\nHeUfAamtH9D9stbWLYk6JU6oNhR9VK+6g2GJuSVGCYgnoI01rPXKVOKS2mJWrsx5zsY+dXGJuFSl\nAq0GmskAfOPlQODI9qx61RlGULznXUQPlIFVp0C3bDTLbaYhKQB6VMlMDMQaQePhUo2mJ6VGUiEG\nZipVJOyR4ePjStgAgxBqUI5gGDv0oPIamBl06US2jMAdNN6RpAAI006GiUIUSQdOlAjaBKtDvU7T\nZKto6xT2kalUQPzrRLSFKIKVADnpvQRpa0Bgg8zUnYyoDnRSWgBGXfbrRCGQYzBQPgJoquLJkb5j\npFPWzlI6RECrNLACSEwBvJpqmO8BP3UFU5bSgGPIDrQhagEEGSeYq8UzBUEiYEeFCKZOpA2qKp1N\n5VGRofjQtwki3WroPSrdxCh3eW8VXYoCi0cV4bUHEeMXc+LKSDtVETGxo/iRzPiz5/iiqlS+ldI4\nX6cpdRKX40xa6gWvXfWiYkWuh1rk6U1S96hUqinLVUWamqVUc1BY8KITecRXOIEKNtZNFaTGmghP\nlO9GLdU4sqWZUTJPWt3gfD9pheEmzbyrSsfrFqGqydD6fKsDidliOH3brKrJ51tB7riU6KHXTT0r\nLtZhiqaU+GlCG+KDDtu8jzRzpFYrbx3gtMcimiH4k52GHXCwYUpPZjxnQ/Ca6XwJa/2dwTYiMrjw\nNwSNzJ0Puj3VzXAsMu+LcXZtmW1ow9tYU85sEjz2mNq7LdtIYt2re3b7qEpQhIE6AQI8dNqLFFeK\n0ISNRrI3EayPCPxorgtnPilw8NQ2jKOY1M6VXX7mY95Ug94ka+taLgdnJhrzxABcc0I5gD/mqtaK\nDmmZ1oxpAUBBMnTTWhWjKhzJNHNJBSDUZSJQNB6UQ22I02+VQduywCtxQSlIkqJgCqZni6zunXG8\nLtMSxXszClWFop1I/mGnuNFahlsHUE+XSjW25BEQd9qyrfFbTGtxhOPW3Uu4Y9HwSaen6QeGmxFx\nePMHo7aPJj3opqNky0coIAChRTLYKjyIFZO1+kPhFw93HLNB/wARRR84q4tOMOGnCAjHsKWT0vG/\nxoL9liUnWT1qdq2AUBl1HhvQVpj2EPK/UYpYuf5X0K++re3ubd09x5pXgFAmikFuZ0iOdeWwZ1EU\ncC2E5jHrS5mYISR4c5oqodahPXqKBeb7yu6QJ+qNYq6eKE5u8B5GgnAMyjIioKe4a1B19aoeIT2V\ng5tMHc1qHsoSTpod+tY7jp4W+GuHQaaUK4BirgXfvq/iNVziudS3Kyp9xR1JJoNxVbcCLV41CpWt\nIo71CpXSgcpetRqVNIomo1Gi4VSqZmpCaZmo1jtl/idth7Pa3bwbB56kqPgBqZqia49wkE9ozepI\n5qbGvLrWQxK/cxC7W86omT3RsEjpFDDeo35OlW/GGA3AHaXJRO4W0aKt7vhfEVBJdwp1ebQOBMk+\nutcsKW1fWQk+YqC7tELt3S0kIWhBWCnTYTQ8nf0MtsW6W2W0MtgQEJTlA02gc9Ko8VVmJPJUxyPX\n3/Oqr6MsWexLhJIuVdo7bOFnMf3kiCAfQx6UbiKz2is3eJ0MmCI0jz/PhRVFfrMKicpJM9fHzrc4\nCz7Nglq2Oacx8zrWEcQbh9DehK1BMesT/SukITkShI1gRp5UqUSykZwRtGlGBRQJSNhzoRgFURIq\na4WEtFJMDqTURnDb/pTjN3b3alDAsLyqu0pJBuXlfVZnoBqY8q0CLhfZhpEMsN91DTIyIQnkABVV\nwgAjgNq41CsTxK5uyTzSFZE/AUYt5q3YW86oISgSVE6AVme/a30tLV+4QIafeT5LIqxZxO/QAE31\nzt/3lRWAa47wxLiiW7xTYMB1DEpPrNG2vH/DpIDt6WldFoP3VR0BrELt0BLzyXtP71CV/wC4U4W9\ng+QbvB8GuJ37TDWD/wClZO2404fWB2eJ25O06ifeK1Ni+1cspeZcS60rUFCgQalgJGEcNLBDvCXD\nCyBqf7MaB94FORwdwXdmXeE8MR/9fMyf/E1IydZAFGsPlJPeASOXWs1qGscAcGbIwm5aET+rxW6S\nB7nBRR4J4X7IJaRjLHQt4rcn/c4amTcjLKTvSm6hHeIMabzWdqqa44IwfUNY9xZbp+yi9Sof+QJo\nVzhHDEJMcV8Wpj7TrCh/+dXDtzm206E1X3CyVROk7E/Or5UVFxwy0kf9PxrjIA2Dtq0v5AVz/wCk\nnCrpiwdP6VuvISn6qrEJJ8JzV0d1RBkRvyrl30r3eXD3EzuY1pzbaX44q57SCf8Aqkn+SoFrup1d\nQf5amcOkUOo612cTFOXH2kH0qMuP/wAFPUajJNFNLr3MJppdd5pFKTTSaGELrn2ab2y/silJps0V\nenavBW00yvJoymSdZpl+52WHXKwdSnIPXT5TS8qBxsn2FAnQua+40WOn/Rtaiz4Ot1nU3K1OkHSe\nUe4DWjL1QUohInNp4nw8xRmDoCeGsJSn6pt0iJ5ACKrr0kx4ok+cmjURYQgP43byZAUXD4xzrfp2\nkjQViOFtcacMahvT4Vtm9d6Uou3VHQetAcTXos8GvXzpkZUoecGKNQSCkDY1l/pGUU8KX8EiUBJ8\nioVEaCza9k4U4YsgCktYc0tX+ZYzH4mqPjMldjbWYMB99KVCYkDea0/EICb1ASICWm0pA5DKNKyn\nEBJxbBUnVJcVp6Vnn4tWFtaoaaCEICUoGgSNqkXagp76QdNiJqdnUGaakSgqO4iKoqbrCLBYl2xZ\nV4qbBqx+jZS7LG8QwxhRNkW0vttqV9QncCorhSspE7mn8Bz+l2Kan9g2N/Og6a2oxoFD00ohL0QC\nQBVegmFCTpUjJKlKSSYg7aViqsUuEd1Ur15mo3Xxl/ejpQaSe2UJMJTpSt99IKtSTzrLR5eUoSNq\nFedEwaa4SVkToNqEkkqkzE1BI+vunXflXGfpZusxQ1/F76644T2J8q4h9KhIvmwDoZrXP06+MA4Z\nFQKNSuVAToa7ORpphNOVUauVAhNNJpd6arQUU1RpNelKabQf/9k=\n', 'hhhhh', 'Belum Proses', '0.0', '0.0', '1', NULL, NULL),
(45, 8, '1', 'hahhahaaa', 'Pendidikan', 'hagahahahha', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdC\nIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAA\nAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlk\nZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAA\nAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAA\nAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\nAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAA\nAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3Bh\ncmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADT\nLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAw\nADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAj\nJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgo\nKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIALsA+gMBIgACEQEDEQH/xAAcAAABBQEB\nAQAAAAAAAAAAAAACAQMEBQYABwj/xABEEAACAQMDAQYCCAQEBAQHAAABAgMABBEFEiExBhMiQVFh\ncYEHFDIzUpGhsSNCwdElc+HwFRYkQxc0Y3JTVGKCk6Lx/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAEC\nAwQF/8QAJhEBAQACAQMEAgMBAQAAAAAAAAECEQMSITEEMkFRE2EUInGBkf/aAAwDAQACEQMRAD8A\n+bFHJ4pSuasEsJmGUiYgdTimpLS47xViiZ3JxtArG3azsirycEda2vZbsNdayiy5CRHzNS+zHYSe\n4C3eqkQwDnBrRal2mt9HgFno+Bt43nn8qznldf1Zknyjah2O0nQYg97dBm/CoyTWC167tnnItIVi\nQcHPOat77VZ79/8AqGLFvU9azOrxMrBjjPpXHjuWV/s1dTwhLBDPI3eOVOM59arnQByFOR61bWlh\nNcDhTip0OiqhzMwFezHG3tHHKyM/FC7HCg1a2Gi3Fyw2oau4Y7a3H8OPcfU1Lj1CeL7nYnwGa7z0\n2dcrzSHLHQFtVWS5lCD3NHfapDpuJLGRu8XgN0FQZpZJW3SyM7e5qh12R12gDw+tXP0uOGNyvdmc\nlzy0japqc95dPPcyGWZuMnyFVjMWOWJJpDyaUCvLJqaju4USjNcoqTbw7jkjiqCtoC3lVvaWQJXP\nWgtogMdBU369bWeDI4JH8o5NBIWwwpJ4Aql1O5igYohDP6Ch1PtBPdZjt17qM+Y6moNrp1xdNkIx\nzVxwuV7JbJ5RMtK+TyTV1pVs0YLuOSOBWj0HsTqFwVMVo5JHVhitbH2KtrKMSa5qdtaJjO3cM/DH\nWvXx44cXfO93PK5ZdsYw4+72gVO03Sr6+OLW1lkJ46VpZNd7G6ICLO1m1ScH7Tjanzqp1D6QtdvE\nMWlwxadbkbQIlAOPc+ddb6i5ezFj8Unuqzg7BzxRd9rV5badFj/vON35Ukl32G0JuPrGsXQx9nwp\n/rWKlivL6Uy391LO/oWJoxbQW6hgoLdBScXLn77o68MfbGlvfpC1XuGi0OwttKtyMAonix8TWUvD\ne6lIJ9Su5ZXPJLHNPMWc8jCj2o2LbSdpyK6Yemwx7s5cuVQ0tYY/Ji3qTTxVegwKcUhkO8+4x51w\nRcEr1HlXWSTwxsOzCdePM01t+NOqD1Y9egHlRcf7NXRt6ZoejQghJ5A2Oqwjcf0q1n1TsnpEJ7uS\nAzqdpSXhw3up5/SvHob66iG2K4mRc5wHIFNTSPcSbpWMjnqW5NfK/g6vl78/V3Oa02Ov9p7nVw62\nzhYB0VT5Vl1iLOXckn3phWEYJyFx15xUeW9BOIQzn26VMvR/tnDl15ifNJFEeSSw5wKrry5N1NlE\nyfKkWF5TmVsD8I6VLjiWNecAV14vSY4d6xnz78AsZbiBGTcNp9ulP53jLHJ9TTLTxqfDz7DmkW9j\nRhvVlB9RXrxuGHh58urJLRcdaUAY86NQGXIOaEg4wa7actkYYwc1HukWWEqy5GOlPDwgikGCOaWb\nml3pj5oyJGCg4zQrG5OAhPyrV/Voly20GnI4lOCqAfKvH/D3fLv+f9MvHbTHkRtipcVtdngIB8a2\nGm6NfX8hW3t22Y+0RhfzrRx9jbexjE+t30NsgH2Wbb/r+lZy4uLj91ameeXiPMBp95KcGTHsKuNH\n7CanqjL3UTnccbmGK2p7S9ltEXbp1o9/OP5yNq/mef2qo1Ltxrd+pjtmSwtyMFYBgke561iYzL2Y\n/wDq7s91T7XsHo2iKJO0OoxIwwTEpyx+X98VKl7Y9ntHjMeiaWJ5F6SzeEA+oHWsJ3LzymSeV3bP\niZuSfnRC2jiLcAnPn1rtj6bKz+1YvLPhc6n241/UkKRzNBCeiQLsWqAwz3Mm+7mdmPBy2alASZ54\nA6AUrc7FHBzz7V3x4Mcfhi8lptbeGOQKB+fnT27CeEYzxTcjBD8fM0cQ3DdjOenvXWSTtGLTkU0k\ncTJHjLdTjn8/SmZAQwyQXHn1xR3DgDahUNjr1qO0bFTukwMcnypkQ7G24E7h/U04XPTacedRYj3J\nAjU7RySR1p3vXdeiknkk9aS/ZYJ1GPDtOT1Ipo43EZ2kdcU4rIGAJPwUUJkC7iFxzwSP6VKsGGjC\n7U8vU80mV9KjlkxhVA9TXeP8LVnqNAe4giyN28+i85pnv5ZjiJNg9TTgRY14QYHmRTfeu7YjXn1r\nhf26y/UF3C4DTyFz7ngV3eKG2xJk+wo4rTIzM2fYU8SsYwoVQK1Mf+M3LYFWXbksEH60qxBuuW/9\n3T8qB7uJDwS5HkKbMtzPgRp3anzNN4/HdO6UWjiXMhAHoKr5JGvZliiXEeeuKcFozOBIxkP6VYwQ\nrAvCir05Z9r2ibmP+nYwIowB5DFCzFsk8ClIyCc0zKh5AY12cxuRjw805AgJw3iJ4Aqx0Ds7f6wy\nGFCkPQyN0+XrWvZOz3ZCMm4f67qIH2F5IPv5L+9cs+fHDt5v0648dy/xQaL2U1DUWDd13MB/mfrj\n2FWssfZrsw2byf67dp/24yGPz8h+tZ/tD2z1HUlaJZDbWzHiGE4J+J6mssIS7bpAeucedcbOXk83\nU/Tc6MfHdrNY+kHU7oGLR7eOwgIxuTl8dPteXyrMSRzXsjSX1xLPKfNiTRh1YFY0O0cVJQsi8ABi\nNxzXXj9Nhj3Yy5cqZt4o0BUKoPvRrtU8ngZ5FN7R3e1nyW5zTzGOOHPGSPDXeTTnSllUZU8njFCu\nHEmQAVyck/lQR4J55I9q4oNw2gkgc0u6FBbu/tAEc8eVLGwwSM4xkg9aFo2LENhVPnjrStGuOHJ9\neaoF9ofcxCgDp1omeQxBlXLdelKiKMiJcgDLHqBT0wdhs3hVxyTxU0pbfSbubT579+6itYyE3u2C\n7ceBR5nBz7DmoahgxABb0FOtK3d93vaRVJO3oMnqf0H5UxtKOW8W0j061z8NCc7pAo8K46DnPxpV\nLs2Nvg6c10aOy+E8nooGaeENyfDtIHm3TNS5SeaaNu4U/wANfbNMvuUruHB6Gp6WkgJzjHxolswG\n3HlhXPLmw+1mNQBFuG4N8N1dn3//AFqwaANndk0H1WP8IrF9Rj8NTCqzb37cnCjrjpStNFD4Yzkj\nyFR4UkuABuCJ6VOt7RYvEi7j5k1rCZZeEysnk2slw+NihAfNqIWUbeKZmYnr5CpOxyN2ABXEAnB5\nHtXaccnnu59d+DUcUMRwqD5U4VZ+MAL5UmQOOgFLnOcVpBquxcJxnrmlLeHA+dCMkYHhHvVhoGj3\nWvahFZWMZeVjyfJR6mlsk3SS1DjSSdkigUtKxwFXnNbjRex0Fnbm/wC0cqxRLgmIn9/U+1a+47N6\nL2C08XkxMl6U6v1J9vTNeSdpddvNZunmvJCsIPgiU4VR8K8v5cubtx9p9u/ROPvl5XvaLti00Jst\nCX6pZgbTKBhmHoPQVhzcAu2072PVjz+dAX+sttLEIPTzqVBGiDaFOMZ5HNdeLixx9rGeVvk2sSL/\nABM5bHQedd4UIwwO4gZ9KdkjCFMN4QOBSZjAyAp2nOfeu2tdmNm2B3hAGPPJHSn437onHjJBBzQK\nsbOShYEjceeaS3tJnYhIXyTgEjoPnTqmPk1twiXPjBAwd2OKK4VdqMo8P8u6pRsZnQZ5bGPE1Ppp\n3GC+B7VjLn458rMMqrWaUxbmACt09hUfewYsQQCORV+tgmQXLPjpuPSpK2kZ+0in4jNcM/VY/DpO\nK/LPBj3exQ7OfQeVSUs5DkJbscjzrRRxKvQAfAU8qVzvrMviNTiigtdOuQx3bEQjoDzmnk0kFdss\njN+lX0UEkrhYkZ2Pkoyas7bsxrV022HTLs582jKj8ziuOXquS/LU4sWTGmQKOhNF9UiHRBXoNp9G\n/aO5PitY4B6yyD+mauLT6INRkUG6v4IT6Ihf9ciuV5cr5rfTPp5QIwPsrikKe1e42n0PWK4N1fXD\nnz2gKP2NXdn9GPZy3wXtnlYfjkY5+WcVnZp84stHDZXNycW9vNKT/wDDQt+1fUtn2S0OzINvplqj\nDzEYzVnHZW8f2IUGPQU2afLVr2O1+8wYdLucHzddv74qw/8ADbtL/wDIr/8AkFfS8o7qMmNQPlUX\n60fQVOpel8MylLSRBCxY59auYWLRBm8xVAtr/wBQFbJb1q/VcQhSelfU4dzbzcmro4zjZxgUyrYb\nnGK5YvMkkUXcljtGSPWu9rloqPbBX77vQT9kpjAPvTWxN52OWXyJ44+FSlt2YlVQgDzq27PJaWWr\nQXOo2huYY2DGNW25I6Z68Vyyzxx72tzG34en/Q19GkN7Cuqa7aiRJBmKGUZAX8RHqfKvcLfRtJ0a\nAyW1lbwKoz4EC/tXlL/THDaQCHTNKbAGMyMB+1ZvXvpP17V4HgCQwROMeEEsPnXzeTky5LuvXjjM\nZ2RPpq7RxazdPCm3urY/axyT6ZrxmNJbuQnY5TyGK2rQtKS0pLZ6k0cdoqgYAA9hXTDm6MemRi4b\nu6zENjcMNqRBV96lxaVMzeJgM/PitItuBu45HUU9HCMgAdeRWr6nP4T8WKii0dXZdzMcg8VKg0a3\nVABGGyCCDzV0kR2qQDyeD7+lPKqgORwOo/qK53lzy81emRWrYxxLwgAK5GBTF1tjZlHBzxj4VY3j\nhI1U8Efsapy5mnJ/CNtYaCq0SrTypRCOgbVKcVfbmnAlOKmKgbVKs+z9pHeazaW8wzG8gDD1FRFX\nirbsqMdobD2lFB9Bm1tNJ0wm1tYkSJMhVUAV5JL9LlzNa3L21vDA0K5wRnk4Ax8yK9ouIFurVoZM\n7XXBxWCm7P8AY/Rb1bWXTIzIy7lyu8nnnrWOzSb9GvaK67Q2ks94Ru9B5c1tqr9HtbGC2DWFukKH\nIwqgdOKnk0V1Rnuh3hSNd5HU5wBT5NVjr/Fmi/GuR8R//RUtEgXnh3sqmP8AErZqQzZXcvPnVDor\nYW6tm6o24fA1b6e+YNh+0h2/2/SmN2ge/LOI3AB8yTTDQZJ4FN6oh7xGTO7NKJXwMsM/Gm/sfGsG\nkSLIXkkB8+BU9bMDhiSKsGxjpXBMmvR+bP7Z/HijJaIo8Kin1hC/ygU+BRBSTzWLlb5rUkgEiHWn\nFjHpTigeVOAD1rKgWMCnAnoOc0oHOcfKleREGXdR8T+tUEFBOPfyo1UEHB4Jx7VDl1GziHiuYhx+\nLOKkWt1BdJvt5UcdCUP2fb40RIAB6DGeB/ejUeg68AD9xTeR5/P+wqu1nWo9MVQU3yt5A4wP70Rc\nggdOg8x5n1oiwVeSODk/H0rCTdsblQWEEQUeXNan62ZtPhlKbGdASuemaqImp3W0E569B7elJp0J\nFurN1bxGoMwNxcxx9dzYJ/etDFHgAAUKbSLPQZou7wcY5p5UTcxkRmVB5etHHHwOBQMiP2ogmKfE\ndFsoI4WrLs0Ma9ZZH/cFRCuKm9nR/jtl/mCpR9Ip9hfhXnXbzvLfX47iLbgWzl97bRgEdPU89K9F\niGI1HtWT7baJNqs1sba37xlYbiZSgxkEg465xXONrXs5N32nZH42/U5/rVrVboVnLZW7pKqruIIU\nHOOAOvyqyPtQJUC9Hd3EUnQA4PwPFT6CWNZFIYZBpUUi28sOtrLGhMTgqxqbbNtv5EXkFcn2Ip36\nkoPDuq+gNOwwRwAhF69T5mpJpTOoQ97CQOtURhkBxhuPjWmagwPSmWOx8iiSLeF71Cx6DcOaCe9t\nrcfxZAD6daw7u00gCZ2KevrVjJZXKxb5QFHozgN+XWuibXj69aL0EjfAUUOvWkkTt41YHG1h1NZC\nZiMKv2j+lT9JsTM58IMUY3SMc4+Hzqm12ur3M0q7ItkLZxJsLdPPrVdd65fRZ/jrgD+VRUzWt9tb\nIve27EqoZYmB2jqF49OM+/wrNJmebc3MaHz/AJjQ2vU168eyCSkCUjlgMGisIHSFrzULeZ4j9gtg\nK3Hof3FVcQVpkEpwhYbj6DzPQ/tU7UpoBGsNkzGLAzk558/IUSqu7kQu7ooRPStV2IsXhtXuZCQ0\n3OPbyrO6VYnVNTS3wTCnilI/b/fvXpkMIjiVFGAoxRTcjiKIyMcKoyceQrJrpNz2hGoX63NpBDbj\nKpLKFZz6KPhVn2tve4thbocO/J+FYknarMTwBk0SnNLsjqGs29rjKKd8nwH+/wBa3t820bR0AwKp\nOwVmVtLjUZBhpW2pkeQqzvn+150C6JAZrySUg4QYGfU/7/WtGEwOOPjUTQLXu7FCftP4z8/9KsZl\n2xng4PBAGTVZvlG7kBmOEO4jOKkBPalihXCBRnYMDnmpGz1otRwnpS7PUVICeldsNERSuc1L7PjG\nuWZwPvB+9Ay+lSNFXGs2f+aP3pVfREf2F+FcetdF92vwrj1rk2Q0hpTQmqENJXV1QITQlh5kUMsI\nkPJNB9WQdcmiDMqebD86a71PxL+dELeMeVJ3Uf4RTur4aEHdLt24NNTgxxhiM5OFHqauU0YO4RtZ\ni3HoBF1/WgvNMtdPz/Ea4uG/nb+X4V1qaUcURUF3OXbk0WSD4SR86fdc03KViQu3l09zUQzJuZ1i\nQ+N+p9B61KCKiBEGFHA/vSWsJjQySffScn2HkP8Af9KdxmgbxTNxJ3cZbz6Ae9SStFpMK3N81xKM\n21tz7M3kKDY9kNIOn6cHlA7+TxufT2rQonNYC41i8lkISZ0XPCrxVfNq9/8AXRBb3cyqBh8N19aK\n0PaXs/qd7qLS2jW/dnGNzYxxUO27EalO22+vIUgB8Qi5J/QVAa4mb7Urn4sauuwU11cajdv3sjWq\nKFAJyN3t/vzojQNbxWNpHbW42xxDaKqXjNxdRQj+dgP71bag3iY+VB2ctjNqDysuRGOvuaDQwQhU\nAUYA4oGDvNsG9NrDJxwwqwWPgCq3UHlSRAsnhJx4OtVmHLGMFpXUEZcgjy4qVsorZQYhgPnz3Dmn\nwnrQMCPn0rtnPrUru+KUxgDpRUFk4NO6OuNYtP8ANX96ddeDkUelJ/i9pnp3i/vSj3qL7tfhSHiu\ni+6X4Vxrk2Q0JpTSGqEPSkLAdTXGqzXQ31NihIxzxUt1NiwM0Y/nX86bNzEP5xUe0t4ZLeN8ZJAp\n76tEB9gVndCPdwgZL1GN+meDxTl3bI0LAKM4rLN3qErk8cVnLOxZHyXve6ug0ZZYojkEeZqTKSxy\nxyfenL2BrBzCsEzBeBtQnNRO9lYgLaXRJ/8ATNephzCo0CC6nMrDMERwo/E1TrbT9Rv8qLc21ueX\nllGDj2pydI4cQw/dpwP71Aw2WJJ6nmk6URoW4BJOAPOoI9y7YWKMbpZDtUfGtPpui3l2sOjaTD31\nwBvkIIHPmSfQdKqez0G6SbVJlIji8MII6n1+VHBeXMF8Lm1mkinB8Lo2DQJrNhLos00dyyGWPK+A\n5GaPsN2bu+0F68VqUWQqZGeQ4VQPU1VatM95epAXLkcux5yfOra0nms0ZbaV4gw2tsbGR70DXaK0\nl0eaa2mKmZTt8BzzW27L6adK7PRLIMTSDe+eOT5H/WsVpNk2s9pre2Ylo4z3kmfavTdSYIAgOAvH\npj+1BQ6g5GcGtD2WtO709XI8Uh3EVm5YzcXUcSjlmA4r0G0gEUKIBjAxVKQJ7VHk06N5xMCyvnPB\n4qyCEDpRhBkcURFEdGI8VJMefKlCZPTFBG2fOlKcc1JEeCaTZyaCE6+1Fpa41W1/zF/ennXA8jS6\ncv8AiVsf/UX96Ue1xfdL8K410HMKfAUprk2E0JpTSE0A1G1CPvLV1x5VKoJBlCKXwK3Q5N1kFPVT\nirKqbSG7u7uIvLORVwaxj4ULDIqrezUuxx1PpVpkEU3tq62j5AOv3J6JEPlUa57TXMCqxSIgnGNt\nVu7AJJwB1o+z9idY1LvHB+rQnj3NejLskaHWtW3WiRRnDuMtjy9qzTc9a7VLgQXciypICGI5U1DO\nowf/AF/lUKl1Hnjlup4bK3BMszAceQoY73vZFS2gknlJ4UDrW+7EdmpbWVtS1IAXMo8KfgFSmlFq\n6Cxji0+IERwjGPU+ZqreQW8DzN5DC/Gt5rXYeHU7x51vJoS5zgcgf6VWt9GUbKVbVZcdcFPP86Gm\nH0eEsXuJPtMeKsZ2EULyN0WtQPozGMJq8igeqf61O0/6MrSOdZL++muUU57vG0H2NERfoy01obC4\n1OdSJLg4TPXbVxqD53c5HTNXl4sdvCIYVCRoMBccAVnNRbCnHz/350DnZa0+s6qZCDiIZ+dbxU8s\nVSdi7LutPMpXDSnPyrSBCDwKJTWwkc/CuEeD0qUEpSnPSio4TI86MJ5VIEYo1T2oIwQChKfrUwxj\nnIoGT1HFVEGSLzpLFP8AEbf/ADB+9Syn5UlqgF9AR+MUqx6zB9ynwFE1Dbn+CnwFETXJoBoDRGhN\nAmaFulLSGgo3P1fV9x4VhzVlJcRlDtcZo5reOUguvI86aNpGOgNY6bPBtXafdSCd1lbw561ZfWI/\nxr+dU9xFJHegKp2GrEQpj7IphL4V8STd5dTpZwHxMfER5Ctnp1/ZaPbpbxKZNo5KjqfOsxYWzWcO\n6T/zEvLHzA9Kd3Yr0Xuztqf+ZLZvvLRm9+DRf8w6aBlrI9M/drWTLU1czCKB3Y8Y4oPUtAurHVIO\n/sI0wPCfCARjyq7RPWsb9FdhNbaRJcS5H1htwX2FbpEPOec1ACpjxVhe1+uTi8NtaylETqV9a2Gu\nXi2GnSzNwQOB6mvJJ5Wmmd2JJY5JNA8NTvVyRdzj/wC81rfou1a9v0vo7qV5oYm8Ducke2fMV59q\nMvdWxC/bbwgV612J0r/gvZeBHz30o7x8eRPpRD+qSDkjrngD+lZyQG4ukiUfaYCrjUJSSf6edB2T\ntfrmsd4wysfPzqjbafb9zbRRgABVA4qWF8XXNPKmAABTioT5CoGdvNOKnp508IgOo5pxUPHpQMCP\nHlRbKkBKIR5PNDSOEzzQvHU0R8HihaPAoK5os8ihgjxdwZ/GKnd160EceLyHj+YUHo1v9wnwomro\nPuE+ApWrm0bIoDThoTQBSEURoTxRAGm2NG1MseaoF1VjkjkUlCzU3voPjaWUySs58zVrc6VG+kx3\n1jKZFAxMh6oaovOnIp5UVkSRgjjxAHg11ZATzXabYvretwWMf3anc59qFuFcjqBWr+iSJCt5KVBk\n3Y3edZtakejWcC21tHCgAVFAGKmDhfam1HNHJxGcehoMJ26v1mvYbNSO7BBbBqV200Xs5pelW509\n3a9kUNgPuHSsdqzs+pzFiSdxqNLI7DLMSQMDJptCaBYf8Z7V2tttLQxHvHx5Y9a9k1EiOJY14VRj\nA/pXn30Nxq17qUpUGQHAbzFbrUyT3mT05oVn798hvMH9f9a1PYax7qyadvtSHgmsndDMgU9DzivS\n9CRU0yAKMDaKonqg2805GuegrgMmn4gKIHu/QU9GntSr9rHlTuMEYqKHZyOKIRZNPKAeopxAB0oq\nOUwMAU20Zx0qcAMdKAAE80EJ4+KaSP8A6mHy8VTpQN3SmAP40f8A7qI2tv8Acp8KM0Ft9wnwpW86\nwpDigJBqsvZpFkIVyBR6dI7r42JrHV301pNNCxpT0ps9a0gXNR3NOSHmmJOhqxDE5bHhqITLnzqW\nelN00P/Z\n', 'hhhhhhh', 'Belum Proses', '0.0', '0.0', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` bigint(20) UNSIGNED NOT NULL,
  `nik` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_tlpn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nik`, `foto_pengguna`, `nama_pengguna`, `email`, `no_tlpn`, `status_pengguna`, `created_at`, `updated_at`) VALUES
(8, '123123123', '', 'Nandia', 'nandiaplaystore@gmail.com', '081234567891', '1', NULL, NULL),
(20, '123456789', 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Kris', 'nandia@corea.co.id', '08123456789', '1', NULL, NULL),
(41, '321321321', 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Siapa yaa', 'nandia@corea.co.id', '081234567892', '1', NULL, NULL),
(48, '43214321', 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Ini Aku', 'nandia@corea.co.id', '0812345678', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'web', '2020-07-21 08:11:31', '2020-07-21 08:11:31'),
(2, 'operator', 'web', '2020-07-21 08:11:31', '2020-07-21 08:11:31'),
(3, 'dinas', 'web', '2020-07-21 08:11:32', '2020-07-21 08:11:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `saran`
--

CREATE TABLE `saran` (
  `id_saran` bigint(20) UNSIGNED NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `id_dinas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul_saran` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_saran` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_pengaduan`
--

CREATE TABLE `status_pengaduan` (
  `id_status_pengaduan` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `status_pengaduan`
--

INSERT INTO `status_pengaduan` (`id_status_pengaduan`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Belum Diproses', NULL, NULL),
(2, 'Sedang Diproses', NULL, NULL),
(3, 'Sudah Diproses', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tempat`
--

CREATE TABLE `tempat` (
  `id_tempat` bigint(20) UNSIGNED NOT NULL,
  `id_kategori_tempat` int(11) NOT NULL,
  `nama_tempat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_tempat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lng` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `tempat`
--

INSERT INTO `tempat` (`id_tempat`, `id_kategori_tempat`, `nama_tempat`, `foto_tempat`, `lat`, `lng`, `created_at`, `updated_at`) VALUES
(2, 1, 'Islamic Center', 'redstonebuild.jpg', '-6.351992355763146', '108.32261075924681', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_dinas` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `id_dinas`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Admin', 'admin@admin.com', NULL, '$2y$10$X.8S8viIeZyy2KVIEaFRG.CkpUVkD6.5gYWTcT.mSlSIE4UhA3KC.', NULL, '2020-07-21 08:11:32', '2020-07-21 08:11:32'),
(2, NULL, 'Operator', 'operator@admin.com', NULL, '$2y$10$vKj1P81MurFcMmR3ajDUteJdf/pGb.Gwcc0skoxp4bmFSOM9mI/HW', NULL, '2020-07-21 08:11:33', '2020-07-21 08:11:33'),
(3, NULL, 'Dinas Perhubungan', 'dishub@admin.com', NULL, '$2y$10$oSi3b8BoQ3/6HtBFN/TJa.8Spr/bZsyRA2orZSwZhak2qBhJQYw92', NULL, '2020-07-21 08:11:33', '2020-07-21 08:11:33'),
(4, 1, 'Dinas Pendidikan', 'disdik@admin.com', NULL, '$2y$10$.lLBTblkRBUNW5VabzUquO6YUOw/H9EGbfJv/AnJAE0a3DfKy9fz6', NULL, '2020-07-21 09:47:02', '2020-07-21 09:47:02'),
(5, 2, 'Kriswantoro', 'id.kriswantoro@gmail.com', NULL, '$2y$10$8VmKgXN1pteNsyfdVU/a6uBVyoe1TKAIc3/IZ8yQni8e.NeRoxZdC', NULL, '2020-07-21 13:34:41', '2020-07-21 13:34:41'),
(6, 3, 'Karina Jaya Mahudi', 'ram@admin.com', NULL, '$2y$10$0ZceVJQ8NJQ10AeDjSM3te4eNhwPhClNuP5H1htcLbwqxNFeImDYS', NULL, '2020-07-21 23:39:11', '2020-07-21 23:39:11'),
(8, NULL, 'Feeding', 'ss@admin.com', NULL, 'password', NULL, '2020-07-22 00:04:56', '2020-07-22 00:04:56'),
(9, 3, 'fajar', 'fajar@gmail.com', NULL, '$2y$10$FWNcm8moYaqToYkH8G4IcOz5zkO9q1f6BqB5ybAIJ0VdwyKcJe0NS', NULL, '2020-07-22 00:12:29', '2020-07-22 00:12:29');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategori_dinas`
--
ALTER TABLE `kategori_dinas`
  ADD PRIMARY KEY (`id_dinas`);

--
-- Indeks untuk tabel `kategori_pengaduan`
--
ALTER TABLE `kategori_pengaduan`
  ADD PRIMARY KEY (`id_kategori_pengaduan`);

--
-- Indeks untuk tabel `kategori_tempat`
--
ALTER TABLE `kategori_tempat`
  ADD PRIMARY KEY (`id_kategori_tempat`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indeks untuk tabel `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indeks untuk tabel `nik_user`
--
ALTER TABLE `nik_user`
  ADD PRIMARY KEY (`nik`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`id_pengaduan`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`),
  ADD UNIQUE KEY `nik` (`nik`),
  ADD UNIQUE KEY `no_tlpn` (`no_tlpn`);

--
-- Indeks untuk tabel `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indeks untuk tabel `saran`
--
ALTER TABLE `saran`
  ADD PRIMARY KEY (`id_saran`);

--
-- Indeks untuk tabel `status_pengaduan`
--
ALTER TABLE `status_pengaduan`
  ADD PRIMARY KEY (`id_status_pengaduan`);

--
-- Indeks untuk tabel `tempat`
--
ALTER TABLE `tempat`
  ADD PRIMARY KEY (`id_tempat`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `image`
--
ALTER TABLE `image`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `kategori_dinas`
--
ALTER TABLE `kategori_dinas`
  MODIFY `id_dinas` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `kategori_pengaduan`
--
ALTER TABLE `kategori_pengaduan`
  MODIFY `id_kategori_pengaduan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kategori_tempat`
--
ALTER TABLE `kategori_tempat`
  MODIFY `id_kategori_tempat` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `id_pengaduan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT untuk tabel `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `saran`
--
ALTER TABLE `saran`
  MODIFY `id_saran` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `status_pengaduan`
--
ALTER TABLE `status_pengaduan`
  MODIFY `id_status_pengaduan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tempat`
--
ALTER TABLE `tempat`
  MODIFY `id_tempat` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
