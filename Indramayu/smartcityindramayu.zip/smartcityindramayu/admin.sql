-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Jul 2020 pada 09.56
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_dinas`
--

CREATE TABLE `kategori_dinas` (
  `id_dinas` bigint(20) UNSIGNED NOT NULL,
  `nama_dinas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kategori_dinas`
--

INSERT INTO `kategori_dinas` (`id_dinas`, `nama_dinas`, `created_at`, `updated_at`) VALUES
(1, 'Dinas Pendidikan', NULL, NULL),
(2, 'Dinas Lingkungan Hidup', NULL, NULL),
(3, 'Dinas PUPR', NULL, NULL),
(4, 'Dinas Kesehatan', NULL, NULL),
(5, 'Dinas Pendidikan dan Olahraga', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_pengaduan`
--

CREATE TABLE `kategori_pengaduan` (
  `id_kategori_pengaduan` int(11) NOT NULL,
  `nama_kategori_pengaduan` varchar(255) NOT NULL,
  `id_dinas` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kategori_pengaduan`
--

INSERT INTO `kategori_pengaduan` (`id_kategori_pengaduan`, `nama_kategori_pengaduan`, `id_dinas`) VALUES
(1, 'Pendidikan', 1),
(2, 'Lingkungan Hidup', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_tempat`
--

CREATE TABLE `kategori_tempat` (
  `id_kategori_tempat` bigint(20) UNSIGNED NOT NULL,
  `nama_kategori` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kategori_tempat`
--

INSERT INTO `kategori_tempat` (`id_kategori_tempat`, `nama_kategori`, `created_at`, `updated_at`) VALUES
(1, 'Ibadah', NULL, NULL),
(2, 'Kesehatan', NULL, NULL),
(3, 'Kantor Polisi', NULL, NULL),
(4, 'Wisata', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2020_05_03_144838_create_pengaduan_table', 1),
(4, '2020_07_12_111531_create_kategori_tempat_table', 1),
(5, '2020_07_12_111846_create_tempat_table', 1),
(6, '2020_07_13_062812_create_saran_table', 1),
(7, '2020_07_13_063351_create_pengguna_table', 1),
(8, '2020_07_13_172029_create_status_pengaduan_table', 1),
(9, '2020_07_18_082600_create_permission_tables', 1),
(10, '2020_07_19_171245_create_kategori_dinas_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(2, 'App\\User', 2),
(3, 'App\\User', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id_pengaduan` bigint(20) UNSIGNED NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `id_dinas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul_pengaduan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pesan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_pengaduan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lokasi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_kirim` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengaduan`
--

INSERT INTO `pengaduan` (`id_pengaduan`, `id_pengguna`, `id_dinas`, `judul_pengaduan`, `kategori`, `pesan`, `foto_pengaduan`, `lokasi`, `status`, `status_kirim`, `created_at`, `updated_at`) VALUES
(9, 1, '1', 'Sekolah', 'Pendidikan', 'sekolah di indramayu kurang banyak', '', '', 'Sudah Diproses', '1', NULL, NULL),
(10, 1, '2', 'Banyak Sampah ', 'Kebersihan Umum', 'banyak smpah berserakan di sekitar POLINDRA', '', '', 'Belum Diproses', '1', NULL, NULL),
(13, 2, '2', 'Pengaduan Nandia', 'Kebersihan Umum', 'banyak smpah berserakan di sekitar POLINDRA', 'https://cdn2.boombastis.com/wp-content/uploads/2018/07/jalan-rusak.jpg', 'Polindra', 'Sedang Proses', '1', NULL, NULL),
(15, 2, '1', 'Coba Pendidikan', 'Pendidikan', 'pendidikan', 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'polindra', 'Belum Proses', '1', NULL, NULL),
(16, 2, '2', 'coba kebersihan', 'Lingkungan Hidup', 'lingkungan hidup', 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'polindra', 'Belum Proses', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` bigint(20) UNSIGNED NOT NULL,
  `foto_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_tlpn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `foto_pengguna`, `nama_pengguna`, `email`, `no_tlpn`, `status_pengguna`, `created_at`, `updated_at`) VALUES
(1, '', 'Rama Alfareza', 'rama@rama.com', '0987654321', '0', NULL, NULL),
(2, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Nandia', 'nandiaplaystore@gmail.com', '081234567891', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'web', '2020-07-21 08:11:31', '2020-07-21 08:11:31'),
(2, 'operator', 'web', '2020-07-21 08:11:31', '2020-07-21 08:11:31'),
(3, 'dinas', 'web', '2020-07-21 08:11:32', '2020-07-21 08:11:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `saran`
--

CREATE TABLE `saran` (
  `id_saran` bigint(20) UNSIGNED NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `id_dinas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul_saran` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_saran` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_pengaduan`
--

CREATE TABLE `status_pengaduan` (
  `id_status_pengaduan` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `status_pengaduan`
--

INSERT INTO `status_pengaduan` (`id_status_pengaduan`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Belum Diproses', NULL, NULL),
(2, 'Sedang Diproses', NULL, NULL),
(3, 'Sudah Diproses', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tempat`
--

CREATE TABLE `tempat` (
  `id_tempat` bigint(20) UNSIGNED NOT NULL,
  `id_kategori_tempat` int(11) NOT NULL,
  `nama_tempat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_tempat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lng` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `tempat`
--

INSERT INTO `tempat` (`id_tempat`, `id_kategori_tempat`, `nama_tempat`, `foto_tempat`, `lat`, `lng`, `created_at`, `updated_at`) VALUES
(2, 1, 'Islamic Center', 'redstonebuild.jpg', '-6.351992355763146', '108.32261075924681', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_dinas` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `id_dinas`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Admin', 'admin@admin.com', NULL, '$2y$10$X.8S8viIeZyy2KVIEaFRG.CkpUVkD6.5gYWTcT.mSlSIE4UhA3KC.', NULL, '2020-07-21 08:11:32', '2020-07-21 08:11:32'),
(2, NULL, 'Operator', 'operator@admin.com', NULL, '$2y$10$vKj1P81MurFcMmR3ajDUteJdf/pGb.Gwcc0skoxp4bmFSOM9mI/HW', NULL, '2020-07-21 08:11:33', '2020-07-21 08:11:33'),
(3, NULL, 'Dinas Perhubungan', 'dishub@admin.com', NULL, '$2y$10$oSi3b8BoQ3/6HtBFN/TJa.8Spr/bZsyRA2orZSwZhak2qBhJQYw92', NULL, '2020-07-21 08:11:33', '2020-07-21 08:11:33'),
(4, 1, 'Dinas Pendidikan', 'disdik@admin.com', NULL, '$2y$10$.lLBTblkRBUNW5VabzUquO6YUOw/H9EGbfJv/AnJAE0a3DfKy9fz6', NULL, '2020-07-21 09:47:02', '2020-07-21 09:47:02'),
(5, 2, 'Kriswantoro', 'id.kriswantoro@gmail.com', NULL, '$2y$10$8VmKgXN1pteNsyfdVU/a6uBVyoe1TKAIc3/IZ8yQni8e.NeRoxZdC', NULL, '2020-07-21 13:34:41', '2020-07-21 13:34:41'),
(6, 3, 'Karina Jaya Mahudi', 'ram@admin.com', NULL, '$2y$10$0ZceVJQ8NJQ10AeDjSM3te4eNhwPhClNuP5H1htcLbwqxNFeImDYS', NULL, '2020-07-21 23:39:11', '2020-07-21 23:39:11'),
(8, NULL, 'Feeding', 'ss@admin.com', NULL, 'password', NULL, '2020-07-22 00:04:56', '2020-07-22 00:04:56'),
(9, 3, 'fajar', 'fajar@gmail.com', NULL, '$2y$10$FWNcm8moYaqToYkH8G4IcOz5zkO9q1f6BqB5ybAIJ0VdwyKcJe0NS', NULL, '2020-07-22 00:12:29', '2020-07-22 00:12:29');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kategori_dinas`
--
ALTER TABLE `kategori_dinas`
  ADD PRIMARY KEY (`id_dinas`);

--
-- Indeks untuk tabel `kategori_pengaduan`
--
ALTER TABLE `kategori_pengaduan`
  ADD PRIMARY KEY (`id_kategori_pengaduan`);

--
-- Indeks untuk tabel `kategori_tempat`
--
ALTER TABLE `kategori_tempat`
  ADD PRIMARY KEY (`id_kategori_tempat`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indeks untuk tabel `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`id_pengaduan`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indeks untuk tabel `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indeks untuk tabel `saran`
--
ALTER TABLE `saran`
  ADD PRIMARY KEY (`id_saran`);

--
-- Indeks untuk tabel `status_pengaduan`
--
ALTER TABLE `status_pengaduan`
  ADD PRIMARY KEY (`id_status_pengaduan`);

--
-- Indeks untuk tabel `tempat`
--
ALTER TABLE `tempat`
  ADD PRIMARY KEY (`id_tempat`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kategori_dinas`
--
ALTER TABLE `kategori_dinas`
  MODIFY `id_dinas` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `kategori_pengaduan`
--
ALTER TABLE `kategori_pengaduan`
  MODIFY `id_kategori_pengaduan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kategori_tempat`
--
ALTER TABLE `kategori_tempat`
  MODIFY `id_kategori_tempat` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `id_pengaduan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `saran`
--
ALTER TABLE `saran`
  MODIFY `id_saran` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `status_pengaduan`
--
ALTER TABLE `status_pengaduan`
  MODIFY `id_status_pengaduan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tempat`
--
ALTER TABLE `tempat`
  MODIFY `id_tempat` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
