-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Jul 2020 pada 21.07
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_tempat`
--

CREATE TABLE `kategori_tempat` (
  `id_kategori_tempat` bigint(20) UNSIGNED NOT NULL,
  `nama_kategori` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kategori_tempat`
--

INSERT INTO `kategori_tempat` (`id_kategori_tempat`, `nama_kategori`, `created_at`, `updated_at`) VALUES
(1, 'Ibadah', NULL, NULL),
(2, 'Wisata', NULL, NULL),
(3, 'Polisi', NULL, NULL),
(4, 'Kesehatan', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2020_05_03_144838_create_pengaduan_table', 1),
(4, '2020_07_12_111531_create_kategori_tempat_table', 1),
(5, '2020_07_12_111846_create_tempat_table', 1),
(6, '2020_07_13_062812_create_saran_table', 1),
(7, '2020_07_13_063351_create_pengguna_table', 1),
(8, '2020_07_13_172029_create_status_pengaduan_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id_pengaduan` bigint(20) UNSIGNED NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `judul_pengaduan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pesan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_pengaduan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lokasi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_status_pengaduan` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengaduan`
--

INSERT INTO `pengaduan` (`id_pengaduan`, `id_pengguna`, `judul_pengaduan`, `kategori`, `pesan`, `foto_pengaduan`, `lokasi`, `id_status_pengaduan`, `created_at`, `updated_at`) VALUES
(1, 1, 'jalan bagus', 'Sedang Diproses', 'Jalanan Rusak Di Jalan Raya Lelea', 'jalan', 'Juntinyuat', 2, NULL, NULL),
(2, 1, 'jalan bagus', 'Sedang Diproses', 'Jalanan Rusak Di Jalan Raya Lelea', 'jalan', 'Juntinyuat', 2, NULL, NULL),
(3, 1, 'jalan bagus', 'Sedang Diproses', 'Jalanan Rusak Di Jalan Raya Lelea', 'jalan', 'Juntinyuat', 2, NULL, NULL),
(4, 1, 'jalan bagus', 'Sedang Diproses', 'Jalanan Rusak Di Jalan Raya Lelea', 'jalan', 'Juntinyuat', 2, NULL, NULL),
(5, 1, 'jalan bagus', 'Sedang Diproses', 'Jalanan Rusak Di Jalan Raya Lelea', 'https://cdn2.boombastis.com/wp-content/uploads/2018/07/jalan-rusak.jpg', 'Juntinyuat', 2, NULL, NULL),
(6, 1, 'jalan bagus', 'Gelandangan', 'Jalanan Rusak Di Jalan Raya Lelea', 'https://cdn2.boombastis.com/wp-content/uploads/2018/07/jalan-rusak.jpg', 'Juntinyuat', 2, NULL, NULL),
(7, 1, 'jalan bagus', 'Gelandangan', 'Jalanan Rusak Di Jalan Raya Lelea', 'https://cdn2.boombastis.com/wp-content/uploads/2018/07/jalan-rusak.jpg', 'Juntinyuat', 1, NULL, NULL),
(8, 1, 'nandia', 'PJU Rusak', 'nandia', '', 'jakarta', 1, NULL, NULL),
(9, 1, 'nandia', 'Tanaman Bermasalah', 'hayyy', 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'jakarta', 1, NULL, NULL),
(10, 1, 'jalan bagus', 'Gelandangan', 'Jalanan Rusak Di Jalan Raya Lelea', 'https://cdn2.boombastis.com/wp-content/uploads/2018/07/jalan-rusak.jpg', 'Juntinyuat', 3, NULL, NULL),
(11, 2, 'jalan bagus', 'Gelandangan', 'Jalanan Rusak Di Jalan Raya Lelea', 'https://cdn2.boombastis.com/wp-content/uploads/2018/07/jalan-rusak.jpg', 'Juntinyuat', 3, NULL, NULL),
(12, 1, '', 'Gelandangan dan Pengemis', '', 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', '', 1, NULL, NULL),
(13, 1, '', 'Gelandangan dan Pengemis', '', 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', '', 1, NULL, NULL),
(14, 0, '', 'Gelandanga', '', 'https://cdn2.boombastis.com/wp-content/uploads/2018/07/jalan-rusak.jpg', 'Juntinyuat', 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` bigint(20) UNSIGNED NOT NULL,
  `foto_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_tlpn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pengguna` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `foto_pengguna`, `nama_pengguna`, `email`, `no_tlpn`, `status_pengguna`, `created_at`, `updated_at`) VALUES
(1, 'https://s.kaskus.id/images/2020/05/20/6816901_20200520052921.jpg', 'Rachel', 'nandiaplaystore@gmail.com', '08991284891', 'aktif', NULL, NULL),
(2, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Rahadian', 'nandiaplaystore@gmail.com', '089912848912', 'aktif', NULL, NULL),
(6, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Rahadian', 'nandiaplaystore@gmail.com', '08991284890', 'aktif', NULL, NULL),
(10, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Nandia', 'nandiaplaystore@gmail.com', '08123456789', 'aktif', NULL, NULL),
(11, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Nandia', 'nandiaplaystore@gmail.com', '08234567891', 'aktif', NULL, NULL),
(12, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Nandia', 'nandiaplaystore@gmail.com', '081234567891', 'aktif', NULL, NULL),
(15, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'nananna', 'Nandiaplaystore@gmail.com', '', 'aktif', NULL, NULL),
(20, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'ccv', 'ggg', '0898546948', 'aktif', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `saran`
--

CREATE TABLE `saran` (
  `id_saran` bigint(20) UNSIGNED NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `judul_saran` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_saran` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `saran`
--

INSERT INTO `saran` (`id_saran`, `id_pengguna`, `judul_saran`, `deskripsi`, `tgl_saran`) VALUES
(1, 0, 'coba', 'desc saran 1', '2020-07-14 23:29:15'),
(2, 0, 'coba', 'desc saran 1', '2020-07-14 23:29:16'),
(3, 0, 'coba', 'desc saran 1', '2020-07-14 23:29:17'),
(4, 0, 'coba', 'desc saran 1', '2020-07-15 21:53:53'),
(5, 0, 'hanya aku', 'hanya aku', '2020-07-16 00:07:20'),
(6, 0, '', '', '2020-07-16 02:01:46');

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_pengaduan`
--

CREATE TABLE `status_pengaduan` (
  `id_status_pengaduan` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `status_pengaduan`
--

INSERT INTO `status_pengaduan` (`id_status_pengaduan`, `status`, `created_at`, `updated_at`) VALUES
(1, 'belum diproses', NULL, NULL),
(2, 'sedang diproses', NULL, NULL),
(3, 'selesai diproses', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tempat`
--

CREATE TABLE `tempat` (
  `id_tempat` bigint(20) UNSIGNED NOT NULL,
  `id_kategori_tempat` int(11) NOT NULL,
  `nama_tempat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_tempat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lng` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `tempat`
--

INSERT INTO `tempat` (`id_tempat`, `id_kategori_tempat`, `nama_tempat`, `foto_tempat`, `lat`, `lng`, `created_at`, `updated_at`) VALUES
(1, 1, 'Masjid', 'https://cdn.rentalmobilbali.net/wp-content/uploads/2016/05/10-Tempat-Wisata-Favorit-Wisatawan-Indonesia-Di-Bali-Unggulan-1024x576.jpg', '-6.408154', '108.281897', NULL, NULL),
(2, 2, 'Wisata', 'https://cdn.rentalmobilbali.net/wp-content/uploads/2016/05/10-Tempat-Wisata-Favorit-Wisatawan-Indonesia-Di-Bali-Unggulan-1024x576.jpg', '-6.408154', '108.281897', NULL, NULL),
(3, 3, 'Polisi', 'https://cdn.rentalmobilbali.net/wp-content/uploads/2016/05/10-Tempat-Wisata-Favorit-Wisatawan-Indonesia-Di-Bali-Unggulan-1024x576.jpg', '-6.408154', '108.281897', NULL, NULL),
(4, 4, 'Kesehatan', 'https://cdn.rentalmobilbali.net/wp-content/uploads/2016/05/10-Tempat-Wisata-Favorit-Wisatawan-Indonesia-Di-Bali-Unggulan-1024x576.jpg', '-6.408154', '108.281897', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin Indramayu', 'admin@admin.com', NULL, '$2y$10$qCdoIczqYYaa978uF3/HeeY6zXkP0v3QUMhpMNcFc1B0IoR059yZ6', NULL, '2020-07-13 11:44:30', '2020-07-13 11:44:30');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kategori_tempat`
--
ALTER TABLE `kategori_tempat`
  ADD PRIMARY KEY (`id_kategori_tempat`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`id_pengaduan`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`),
  ADD UNIQUE KEY `no_tlpn` (`no_tlpn`);

--
-- Indeks untuk tabel `saran`
--
ALTER TABLE `saran`
  ADD PRIMARY KEY (`id_saran`);

--
-- Indeks untuk tabel `status_pengaduan`
--
ALTER TABLE `status_pengaduan`
  ADD PRIMARY KEY (`id_status_pengaduan`);

--
-- Indeks untuk tabel `tempat`
--
ALTER TABLE `tempat`
  ADD PRIMARY KEY (`id_tempat`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kategori_tempat`
--
ALTER TABLE `kategori_tempat`
  MODIFY `id_kategori_tempat` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `id_pengaduan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `saran`
--
ALTER TABLE `saran`
  MODIFY `id_saran` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `status_pengaduan`
--
ALTER TABLE `status_pengaduan`
  MODIFY `id_status_pengaduan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tempat`
--
ALTER TABLE `tempat`
  MODIFY `id_tempat` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
