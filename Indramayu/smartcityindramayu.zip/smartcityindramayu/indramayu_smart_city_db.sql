-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Jul 2020 pada 12.39
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indramayu_smart_city_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(5) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_tempat`
--

CREATE TABLE `kategori_tempat` (
  `id_kategori_tempat` int(5) NOT NULL,
  `nama_tempat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori_tempat`
--

INSERT INTO `kategori_tempat` (`id_kategori_tempat`, `nama_tempat`) VALUES
(1, 'Ibadah'),
(2, 'Wisata'),
(3, 'Polisi'),
(4, 'Kesehatan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id_pengaduan` int(5) NOT NULL,
  `judul_pengaduan` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `pesan` text NOT NULL,
  `foto_pengaduan` varchar(255) NOT NULL,
  `lokasi_pengaduan` varchar(255) NOT NULL,
  `id_status_pengaduan` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengaduan`
--

INSERT INTO `pengaduan` (`id_pengaduan`, `judul_pengaduan`, `kategori`, `pesan`, `foto_pengaduan`, `lokasi_pengaduan`, `id_status_pengaduan`) VALUES
(1, 'Pengaduan tentang jalanan rusak', 'Rambu Jalan', 'Jalanan disini banyak berlubang harap diperbaiki yaa', '08960753569', 'Pantura Larangan', '1'),
(2, 'Lampu lalulintas pada mati', 'Jalanan dan Rambu Lalulintas', 'harap di benerin yaa pak', '0895555484597', 'jalan celeng', '1'),
(3, 'Anak Hilang', 'Orang Hilang', 'Anak ku yg bernama hilang', '0876648469484', 'Sindang', '2'),
(5, 'babi', 'Mobilitas dan Akses', 'babi', '8554616', 'babi', '1'),
(6, 'jalan bagus', 'Sedang Diproses', 'Jalanan Rusak Di Jalan Raya Lelea', 'jalan', 'Juntinyuat', '1'),
(7, 'coba lagi', 'Kaki Lima Liar', 'kaki lima', '949646464', 'indramayu', ''),
(8, 'jalan bagus', 'Sedang Diproses', 'Jalanan Rusak Di Jalan Raya Lelea', 'jalan', 'Juntinyuat', '2'),
(9, 'terakhir', 'Gelandangan dan Pengemis', 'terakhir', '134345', 'indramayu', '1'),
(10, 'gambar', 'Banjir', 'gambar', 'data:image/jpg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdC\nIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAA\nAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlk\nZX', 'rumah', '1'),
(11, 'lagi', 'Gelandangan dan Pengemis', 'yyyy', 'data:image/jpg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdC\nIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAA\nAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlk\nZX', 'hahaha', '1'),
(12, 'thvyv', 'Gelandangan dan Pengemis', 'yvyvyby', '', 'vgvyvy', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(5) NOT NULL,
  `foto_pengguna` varchar(255) DEFAULT NULL,
  `nama_pengguna` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `no_tlpn` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `foto_pengguna`, `nama_pengguna`, `email`, `no_tlpn`) VALUES
(1, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Kriswantoro', 'id.kriswantoro@gmail.com', '089607424689'),
(2, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'nandianugraha', 'nandiaplaystore@gmail.com', '08991284891'),
(3, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'jshsbs', 'nandiaplaystore2@gmail.com', '12341231123'),
(4, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Tuti', 'kriswantoro1409@gmail.com', '80794846484'),
(5, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Nandia Rahadian Nugraha', 'nandiaplaystore@gmail.com', '08991284890'),
(10, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Rahadian', 'nandiaplaystore@gmail.com', '089912848912'),
(11, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'saya', 'saya@hotmail.com', '123456123456'),
(12, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Hari', 'nandia@corea.co.id', '123456'),
(13, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'hay', 'hay', '654321');

-- --------------------------------------------------------

--
-- Struktur dari tabel `saran`
--

CREATE TABLE `saran` (
  `id_saran` int(5) NOT NULL,
  `judul_saran` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `tgl_saran` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `saran`
--

INSERT INTO `saran` (`id_saran`, `judul_saran`, `deskripsi`, `tgl_saran`) VALUES
(1, 'Jalanan', 'jdkajdkahdkhakdhka', '2020-07-12 18:53:48'),
(2, 'Pembangunan', 'jalanabaajan', '2020-07-12 18:53:48'),
(3, 'nsksnznxb', 'bsisnsndn', '2020-07-12 18:53:48'),
(4, 'nsksnznxb', 'bsisnsndn', '2020-07-12 18:53:48'),
(5, 'eddf', 'dddff', '2020-07-12 18:53:48'),
(6, 'Saran 1', 'desc saran 1', '2020-07-12 18:53:48'),
(7, 'coba', 'coba', '2020-07-12 18:53:48'),
(8, 'satu', 'satu', '2020-07-12 18:53:48'),
(9, 'hahahaha', 'hahahaha', '2020-07-12 18:53:48'),
(10, 'coba tanggal', 'coba tanggal', '2020-07-12 18:53:48'),
(11, 'Saran 1', 'desc saran 1', '2020-07-12 02:04:18'),
(12, 'Saran 1', 'desc saran 1', '2020-07-13 02:04:18'),
(15, 'yyyy', 'yyyy', '2020-07-13 02:27:34'),
(16, 'Saran 1', 'desc saran 1', '2020-07-12 21:32:56'),
(17, 'coba', 'desc saran 1', '2020-07-12 21:33:14'),
(18, 'coba', 'desc saran 1', '2020-07-12 21:34:03'),
(19, 'coba', 'desc saran 1', '1970-01-01 07:00:01'),
(20, 'coba', 'desc saran 1', '2020-07-13 02:36:07'),
(21, 'tai', 'tai', '2020-07-13 02:38:05'),
(22, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Nandia Rahadian Nugraha', '2020-07-13 17:17:32'),
(23, 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg', 'Nandia Rahadian Nugraha', '2020-07-13 17:18:16');

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_pengaduan`
--

CREATE TABLE `status_pengaduan` (
  `id_status_pengaduan` int(11) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `status_pengaduan`
--

INSERT INTO `status_pengaduan` (`id_status_pengaduan`, `status`) VALUES
(1, 'Sedang Diproses'),
(2, 'Selesai');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tempat`
--

CREATE TABLE `tempat` (
  `id_tempat` int(5) NOT NULL,
  `id_kategori_tempat` varchar(255) NOT NULL,
  `nama_tempat` varchar(255) NOT NULL,
  `foto_tempat` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL,
  `lng` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tempat`
--

INSERT INTO `tempat` (`id_tempat`, `id_kategori_tempat`, `nama_tempat`, `foto_tempat`, `lat`, `lng`) VALUES
(1, '2', 'Polindra', 'https://lh3.googleusercontent.com/proxy/GMYFSS-LSPR0qafrce7fUkq601qSfMQ4Ea9CV_b3VxegCSj1ZnpLaGskL4HncSCLP1d8raALrkD-6sNvA7mCcNPNAeng-DfweeyWMSXQMYDm7narn_xe6JXaBlOC-l1Ym5D0_s4lQsYpM9S8JZtW', '-6.408154', '108.281897'),
(2, '1', 'Masjid Nurul Hidayah', 'https://fastly.4sqi.net/img/general/600x600/31390668_5Xq-v_2o8bUek5pbMt5Koz3IRKtLbbbhSNUy2bIyigM.jpg', '-6.431641', '108.437159'),
(3, '3', 'Kantor Polisi', 'https://lh3.googleusercontent.com/proxy/GMYFSS-LSPR0qafrce7fUkq601qSfMQ4Ea9CV_b3VxegCSj1ZnpLaGskL4HncSCLP1d8raALrkD-6sNvA7mCcNPNAeng-DfweeyWMSXQMYDm7narn_xe6JXaBlOC-l1Ym5D0_s4lQsYpM9S8JZtW', '-6.431641', '108.437159'),
(4, '4', 'Rumah Sakit', 'https://fastly.4sqi.net/img/general/600x600/31390668_5Xq-v_2o8bUek5pbMt5Koz3IRKtLbbbhSNUy2bIyigM.jpg', '-6.431641', '108.437159');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `kategori_tempat`
--
ALTER TABLE `kategori_tempat`
  ADD PRIMARY KEY (`id_kategori_tempat`);

--
-- Indeks untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`id_pengaduan`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`),
  ADD UNIQUE KEY `no_tlpn` (`no_tlpn`);

--
-- Indeks untuk tabel `saran`
--
ALTER TABLE `saran`
  ADD PRIMARY KEY (`id_saran`);

--
-- Indeks untuk tabel `status_pengaduan`
--
ALTER TABLE `status_pengaduan`
  ADD PRIMARY KEY (`id_status_pengaduan`);

--
-- Indeks untuk tabel `tempat`
--
ALTER TABLE `tempat`
  ADD PRIMARY KEY (`id_tempat`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `kategori_tempat`
--
ALTER TABLE `kategori_tempat`
  MODIFY `id_kategori_tempat` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `id_pengaduan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `saran`
--
ALTER TABLE `saran`
  MODIFY `id_saran` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `status_pengaduan`
--
ALTER TABLE `status_pengaduan`
  MODIFY `id_status_pengaduan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tempat`
--
ALTER TABLE `tempat`
  MODIFY `id_tempat` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
