<?php
 
class DBOperations
{
    private $con;
 
    function __construct()
    {
        require_once dirname(__FILE__) . '\DBConnect.php';
        $db = new DBConnect();
        $this->con = $db->connect();
    }

	//postPengaduan
	public function postPengaduan($id_pengguna, $id_dinas, $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi, $status, $status_kirim){
		$kirim = 1;
		$stmt = $this->con->prepare("INSERT INTO pengaduan (id_pengguna, id_dinas, judul_pengaduan, kategori, pesan, foto_pengaduan, lokasi, status, status_kirim) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("sssssssss", $id_pengguna, $id_dinas, $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi, $status, $kirim);
		if($stmt->execute())
			return true; 
		return false; 
	}
	
	//getPengaduan
	public function getPengaduan(){
		$stmt = $this->con->prepare("SELECT id_pengaduan, pengaduan.id_pengguna, id_dinas, judul_pengaduan, kategori, pesan, foto_pengaduan, lokasi, status, pengguna.foto_pengguna, pengguna.nama_pengguna FROM `pengaduan` INNER JOIN pengguna ON pengaduan.id_pengguna=pengguna.id_pengguna");
		$stmt->execute();
		$stmt->bind_result($id_pengaduan, $id_pengguna, $id_dinas, $judul_pengaduan, $kategori, $pesan, $foto_pengaduan, $lokasi, $status, $foto_pengguna, $nama_pengguna);
		$pengaduan = array();
		
		while($stmt->fetch()){
			$temp = array(); 
			$temp['id_pengaduan'] = $id_pengaduan;
			$temp['id_pengguna'] = $id_pengguna;
			$temp['id_dinas'] = $id_dinas;
			$temp['judul_pengaduan'] = $judul_pengaduan; 
            $temp['kategori'] = $kategori; 
            $temp['pesan'] = $pesan; 
            $temp['foto_pengaduan'] = $foto_pengaduan; 
			$temp['lokasi'] = $lokasi; 
			$temp['status'] = $status;
			$temp['foto_pengguna'] = $foto_pengguna;
			$temp['nama_pengguna'] = $nama_pengguna;
			array_push($pengaduan, $temp);
		}
		return $pengaduan; 
	}

	//getKategoriTempat
	public function getKategori(){
		$stmt = $this->con->prepare("SELECT id_kategori_tempat, nama_kategori FROM kategori_tempat");
		$stmt->execute();
		$stmt->bind_result($id_kategori_tempat, $nama_kategori);
		$kategori = array();
		
		while($stmt->fetch()){
			$temp = array();
			$temp['id_kategori_tempat'] = $id_kategori_tempat; 
			$temp['nama_kategori'] = $nama_kategori;
			array_push($kategori, $temp);
		}
		return $kategori; 
	}

		//getKategoriPengaduan
		public function getKategoriPengaduan(){
			$stmt = $this->con->prepare("SELECT id_kategori_pengaduan, nama_kategori_pengaduan, kategori_dinas.id_dinas, kategori_dinas.nama_dinas FROM `kategori_pengaduan` INNER JOIN kategori_dinas ON kategori_pengaduan.id_dinas=kategori_dinas.id_dinas");
			$stmt->execute();
			$stmt->bind_result($id_kategori_pangaduan, $nama_kategori_pengaduan, $id_dinas, $nama_dinas);
			$kategoriPengaduan = array();
			
			while($stmt->fetch()){
				$temp = array();
				$temp['id_kategori_pengaduan'] = $id_kategori_pangaduan; 
				$temp['id_dinas'] = $id_dinas;
				$temp['nama_kategori_pengaduan'] = $nama_kategori_pengaduan;
				$temp['nama_dinas'] = $nama_dinas;
				array_push($kategoriPengaduan, $temp);
			}
			return $kategoriPengaduan; 
		}
	
	//getTempat
	public function getTempat(){
		if (isTheseParametersAvailable(array('id_kategori_tempat'))) {
			$id_kategori_tempat = $_POST['id_kategori_tempat'];

		$stmt = $this->con->prepare("SELECT id_tempat, tempat.id_kategori_tempat, nama_tempat, foto_tempat, lat, lng, kategori_tempat.id_kategori_tempat, kategori_tempat.nama_kategori FROM tempat INNER JOIN kategori_tempat ON tempat.id_kategori_tempat=kategori_tempat.id_kategori_tempat WHERE tempat.id_kategori_tempat = ?");
		$stmt->bind_param("s",$id_kategori_tempat);
		$stmt->execute();
		$stmt->store_result();
		//$stmt->bind_result($id_tempat, $id_kategori_tempat, $nama_tempat, $foto_tempat, $lat, $lng, $id_kategori_tempat2, $nama_tempat2);
		$tempat = array();

		if($stmt->num_rows > 0){
			$stmt->bind_result($id_tempat, $id_kategori_tempat, $nama_tempat, $foto_tempat, $lat, $lng, $id_kategori_tempat2, $nama_tempat2);
			$stmt->fetch();
		
		//while($stmt->fetch()){
			$temp = array(
						'id_tempat'=>$id_tempat,
						'id_kategori_tempat'=>$id_kategori_tempat,
						'nama_tempat'=>$nama_tempat,
            			'foto_tempat'=>$foto_tempat, 
            			'lat'=>$lat,
						'lng'=>$lng,
						'kategori_tempat.id_kategori_tempat'=>$id_kategori_tempat2,
						'kategori_tempat.nama_kategori'=>$nama_tempat2);
			array_push($tempat, $temp);
			}
		return $tempat; 
		}
	}

	//getsaran
	public function getSaran(){
		$stmt = $this->con->prepare("SELECT id_saran, judul_saran, deskripsi, tgl_saran FROM saran");
		$stmt->execute();
		$stmt->bind_result($id_saran, $judul_saran, $deskripsi, $tgl_saran);
		$getsaran = array();
		
		while($stmt->fetch()){
			$temp = array();
			$temp['id_saran'] = $id_saran; 
			$temp['judul_saran'] = $judul_saran;
			$temp['deskripsi'] = $deskripsi;
			$temp['tgl_saran'] = $tgl_saran;
			array_push($getsaran, $temp);
		}
		return $getsaran; 
	}

	public function postSaran($judul_saran, $deskripsi, $tgl_saran){
		$timezone = date_default_timezone_set("Asia/Bangkok");
		$currentDateTime = date('Y-m-d H:i:s');
		$stmt = $this->con->prepare("INSERT INTO saran (judul_saran, deskripsi, tgl_saran) VALUES (?, ?, ?)");
		$stmt->bind_param("sss", $judul_saran, $deskripsi, $currentDateTime);
		if($stmt->execute())
			return true; 
		return false; 
	}

		//getUser
		public function getUser(){
			$stmt = $this->con->prepare("SELECT id_pengguna, foto_pengguna, nama_pengguna, email, no_tlpn, status_pengguna FROM pengguna");
			$stmt->execute();
			$stmt->bind_result($id_pengguna, $foto_pengguna, $nama_pengguna, $email, $no_tlpn, $status_pengguna);
			$getuser = array();
			
			while($stmt->fetch()){
				$temp = array();
				$temp['id_pengguna'] = $id_pengguna; 
				$temp['foto_pengguna'] = $foto_pengguna;
				$temp['nama_pengguna'] = $nama_pengguna;
				$temp['email'] = $email;
				$temp['no_tlpn'] = $no_tlpn;
				$temp['status_pengguna'] = $status_pengguna;
				array_push($getuser, $temp);
			}
			return $getuser; 
		}

		//getlogin
	public function getlogin(){
		if (isTheseParametersAvailable(array('no_tlpn'))) {
			$no_tlpn = $_POST['no_tlpn'];

		$stmt = $this->con->prepare("SELECT id_pengguna, foto_pengguna, nama_pengguna, email, no_tlpn, status_pengguna FROM pengguna WHERE no_tlpn = ?");
		$stmt->bind_param("s",$no_tlpn);
		$stmt->execute();
		$stmt->store_result();
		$getlogin = array();

		if($stmt->num_rows > 0){
			$stmt->bind_result($id_pengguna, $foto_pengguna, $nama_pengguna, $email, $no_tlpn, $status_pengguna);
			$stmt->fetch();
		
		//while($stmt->fetch()){
			$temp = array(
						'id_pengguna'=>$id_pengguna,
						'foto_pengguna'=>$foto_pengguna,
						'nama_pengguna'=>$nama_pengguna,
            			'email'=>$email, 
						'no_tlpn'=>$no_tlpn,
						'status_pengguna'=>$status_pengguna);
			array_push($getlogin, $temp);
			}
		return $getlogin; 
		}
	}

	//postregister
	public function postRegister($foto_pengguna, $nama_pengguna, $email, $no_tlpn, $status_pengguna){
		$status = 1;
		$stmt = $this->con->prepare("INSERT INTO pengguna (foto_pengguna, nama_pengguna, email, no_tlpn, status_pengguna) VALUES ( ?, ?, ?, ?, ?)");
		$stmt->bind_param("sssss", $foto_pengguna, $nama_pengguna, $email, $no_tlpn, $status);
		if($stmt->execute())
			return true; 
		return false; 
	}
}