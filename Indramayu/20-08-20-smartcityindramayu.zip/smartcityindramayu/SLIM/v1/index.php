<?php 
	
	require_once '../include/DBOperations.php';
	$response = array();  
	
	$target_dir = "uploads/";

	if(isset($_GET['apicall'])){
		
		switch($_GET['apicall']){	

			case 'postpengaduan':
                if(
				isset($_POST['id_pengguna']) &&
				isset($_POST['id_dinas']) &&
                isset($_POST['judul_pengaduan']) &&
				isset($_POST['kategori']) && 
                isset($_POST['pesan']) &&
                isset($_POST['foto_pengaduan']) &&
				isset($_POST['lokasi']) &&
				isset($_POST['status']) &&
				isset($_POST['lat']) &&
				isset($_POST['lng']) &&
				isset($_POST['tgl_pengaduan']) &&
				isset($_POST['status_kirim'])){
                    $db = new DBOperations();
					if($db->postPengaduan($_POST['id_pengguna'], $_POST['id_dinas'], $_POST['judul_pengaduan'], $_POST['kategori'], $_POST['pesan'], $_POST['foto_pengaduan'], $_POST['lokasi'], $_POST['status'], $_POST['lat'], $_POST['lng'], $_POST['tgl_pengaduan'], $_POST['status_kirim'])){
						$response['status'] = 'sukses';
						$response['code'] = 200;
                        $response['message'] = 'pengaduan added successfully';
					}else{
						$response['status'] = 'error';
						$response['code'] = 300;
						$response['message'] = 'Could not add pengaduan';
					}
				}else{
					$response['status'] = 'error';
					$response['code'] = 400; 
					$response['message'] = 'Required Parameters are missing';
				}
			break; 
			
			case 'getpengaduan':
				$db = new DBOperations();
				$pengaduan = $db->getPengaduan();
				if(count($pengaduan)<=0){
					$response['error'] = true; 
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false; 
					$response['count'] = count($pengaduan);
					$response['data'] = $pengaduan;

				}
			break; 

			case 'gettempat':
				$db = new DBOperations();
				$tempat = $db->getTempat();
				if(count($tempat)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['message'] = 'Sukses';
					$response['data'] = $tempat;
				}
			break;

			case 'getkategori':
				$db = new DBOperations();
				$kategori = $db->getKategori();
				if(count($kategori)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['data'] = $kategori;
				}
			break;

			case 'getkategoripengaduan':
				$db = new DBOperations();
				$kategoriPengaduan = $db->getKategoriPengaduan();
				if(count($kategoriPengaduan)<=0){
					$response['status'] = 'error';
					$response['code'] = 302;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['status'] = 'sukses';
					$response['code'] = 200;
					$response['response'] = $kategoriPengaduan;
				}
			break;

			case 'getsaran':
				$db = new DBOperations();
				$saran = $db->getSaran();
				if(count($saran)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['code'] = 200;
					$response['response'] = $saran;
				}
			break;

			case 'getkategoridinas':
				$db = new DBOperations();
				$kategoridinas = $db->getKategoriDinas();
				if(count($kategoridinas)<=0){
					$response['status'] = 'error';
					$response['code'] = 302;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['status'] = 'sukses';
					$response['code'] = 200;
					$response['response'] = $kategoridinas;
				}
			break;
			
			case 'getriwayat':
				$db = new DBOperations();
				$riwayat = $db->getRiwayatPengaduan();
				if(count($riwayat)<=0){
					$response['error'] = true;
					$response['code'] = 302;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['code'] = 200;
					$response['response'] = $riwayat;
				}
			break;

			case 'postsaran':
                if(
				isset($_POST['id_pengguna']) &&
				isset($_POST['id_dinas']) &&
                isset($_POST['judul_saran']) &&
				isset($_POST['deskripsi']) &&
				isset($_POST['tgl_saran'])){
                    $db = new DBOperations();
					if($db->postSaran($_POST['id_pengguna'], $_POST['id_dinas'], $_POST['judul_saran'], $_POST['deskripsi'], $_POST['tgl_saran'])){
						$response['error'] = false;
                        $response['message'] = 'saran added successfully';
					}else{
						$response['error'] = true;
						$response['message'] = 'Could not add pengaduan';
					}
				}else{
					$response['error'] = true; 
					$response['message'] = 'Required Parameters are missing';
				}
			break;
			
			case 'getuser':
				$db = new DBOperations();
				$getuser = $db->getUser();
				if(count($getuser)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['data'] = $getuser;
				}
			break;

			case 'getlogin':
				$db = new DBOperations();
				$getlogin = $db->getLogin();
				if(count($getlogin)<=0){
					$response['error'] = true;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['error'] = false;
					$response['message'] = 'Sukses';
					$response['data'] = $getlogin;
				}
			break;

			case 'checkNik':
				$db = new DBOperations();
				$checkNik = $db->checkNIK();
				if(count($checkNik)<=0){
					// $response['status'] = 'error';
					// $response['code'] = 302;
					$response['error'] = true;
					$response['response'] = 'Nothing found in the database';
				}else{
					// $response['status'] = 'sukses';
					// $response['code'] = 200;
					$response['error'] = false;
					$response['message'] = 'Sukses';
					$response['response'] = $checkNik;
				}
			break;

			case 'postregister':
                if(
				isset($_POST['nik']) &&
                isset($_POST['foto_pengguna']) &&
				isset($_POST['nama_pengguna']) &&
				isset($_POST['email']) &&
				isset($_POST['no_tlpn']) &&
				isset($_POST['status_pengguna'])){
                    $db = new DBOperations();
					if($db->postRegister($_POST['nik'], $_POST['foto_pengguna'], $_POST['nama_pengguna'], $_POST['email'], $_POST['no_tlpn'], $_POST['status_pengguna'])){
						$response['code'] = 200;
                        $response['message'] = 'register user added successfully';
					}else{
						$response['code'] = 400;
						$response['message'] = 'Could not register';
					}
				}else{
					$response['error'] = true; 
					$response['message'] = 'Required Parameters are missing';
				}
			break;

			case 'updateuser':
				if(
					isset($_POST['foto_pengguna']) &&
					isset($_POST['no_tlpn']) &&
					isset($_POST['id_pengguna'])){
						$db = new DBOperations();
						if($db->updateUser($_POST['foto_pengguna'], $_POST['no_tlpn'], $_POST['id_pengguna'])){
							$response['code'] = 200;
							$response['message'] = 'update user added successfully';
						}else{
							$response['code'] = 400;
							$response['message'] = 'Could not update';
						}
					}
				break;
				

			case 'addnomor':
                if(
				isset($_POST['nama']) &&
                isset($_POST['nomor'])){
                    $db = new DBOperations();
					if($db->addNomor($_POST['nama'], $_POST['nomor'])){
						$response['code'] = 200;
                        $response['message'] = 'nomor added successfully';
					}else{
						$response['code'] = 400;
						$response['message'] = 'Could not register';
					}
				}else{
					$response['error'] = true; 
					$response['message'] = 'Required Parameters are missing';
				}
			break;

			case 'getpanggilan':
				$db = new DBOperations();
				$getNomor = $db->getNomor();
				if(count($getNomor)<=0){
					$response['code'] = 302;
					$response['message'] = 'Nothing found in the database';
				}else{
					$response['code'] = 200;
					$response['message'] = 'Sukses';
					$response['response'] = $getNomor;
				}
			break;

			default:
				$response['error'] = true;
				$response['message'] = 'No operation to perform';
			
		}
		
	}else{
		$response['error'] = false; 
		$response['message'] = 'Invalid Request';
	}
	
	//displaying the data in json 
	echo json_encode($response);
	function isTheseParametersAvailable($params){
		foreach ($params as $param) {
			if (!isset($_POST[$param])) {
				return false;
			}
		}
	
		return true;
	}

	function getBaseURL(){
        $url  = isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
        $url .= $_SERVER['SERVER_NAME'];
        $url .= $_SERVER['REQUEST_URI'];
        return dirname($url) . '/';
	}
	